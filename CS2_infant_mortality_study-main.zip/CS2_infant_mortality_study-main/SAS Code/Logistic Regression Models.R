#                       STAT 634 - CASE STUDY 2

################################################################################
#                     Logistic Regression Models
################################################################################
# coded by: Jonathan Abbamonte

# load libraries
library(haven)
library(tidyverse)
library(grplasso)
library(SGL)
library(pROC)
library(grpreg)
library(survival)
library(PredictABEL)
library(speedglm)
library(statmod)
library(aod)
library(boot)
library(pcalg)



#################################################
# Load Dataset
#################################################
co15.a <- read.csv("Data/co15_a.csv", header=TRUE)



#################################################
# Recoding
#################################################
# convert categorical variables to factors
# BFACIL_r
unique(co15.a$BFACIL_r)
co15.a$BFACIL_r <- factor(co15.a$BFACIL_r,
                          levels = c( "Hospital",
                                      "Home(intended)/Birth Center",
                                      "Other"))
# MAGER9_r
unique(co15.a$MAGER9_r)
co15.a$MAGER9_r <- factor(co15.a$MAGER9_r,
                          levels = c("Under 15 years",
                                     "15-19 years",
                                     "20-24 years",
                                     "25-29 years",
                                     "30-34 years",
                                     "35-39 years",
                                     "40-44 years",
                                     "45-49 years",
                                     "50-54 years"))
co15.a$MAGER9_r <- relevel(co15.a$MAGER9_r, ref="20-24 years")

# MBSTATE_REC_r
unique(co15.a$MBSTATE_REC_r)
co15.a$MBSTATE_REC_r <- factor(co15.a$MBSTATE_REC_r,
                               levels = c("Born in the U.S.",
                                          "Born outside the U.S."))
co15.a$MBSTATE_REC_r <- relevel(co15.a$MBSTATE_REC_r, ref="Born in the U.S.")

# MRACE6_r
unique(co15.a$MRACE6_r)
co15.a$MRACE6_r <- factor(co15.a$MRACE6_r,
                          levels = c(  "White (only)",
                                       "Black (only)",
                                       "AIAN/NHOPI",
                                       "Asian (only)",
                                       "More than one race"))
co15.a$MRACE6_r <- relevel(co15.a$MRACE6_r, ref="White (only)")

# DMAR_r
unique(co15.a$DMAR_r)
co15.a$DMAR_r <- factor(co15.a$DMAR_r,
                        levels = c("Married", "Unmarried"))
co15.a$DMAR_r <- relevel(co15.a$DMAR_r, ref="Married")

# MEDUC_r
unique(co15.a$MEDUC_r)
co15.a$MEDUC_r <- factor(co15.a$MEDUC_r,
                         levels = c( "8th grade or less",
                                     "9th-12th grade, no diploma",
                                     "High school diploma",
                                     "Some college, no degree",
                                     "Associate degree",
                                     "Bachelor's degree",
                                     "Master's degree",
                                     "Doctorate/Professional"))
co15.a$MEDUC_r <- relevel(co15.a$MEDUC_r, ref="High school diploma")

# TBO_REC_r
unique(co15.a$TBO_REC_r)
co15.a$TBO_REC_r <- factor(co15.a$TBO_REC_r,
                           levels = c( "1 total birth order",
                                       "2 total birth order",
                                       "3 total birth order",
                                       "4 total birth order",
                                       "5 total birth order",
                                       "6 total birth order",
                                       "7 or more total births"))
co15.a$TBO_REC_r <- relevel(co15.a$TBO_REC_r, ref="1 total birth order")

# ILLB_R11_r
unique(co15.a$ILLB_R11_r)
co15.a$ILLB_R11_r <- factor(co15.a$ILLB_R11_r,
                            levels = c( "1st birth",
                                        "0-3 mo.",
                                        "4-11 mo.",
                                        "12-17 mo.",
                                        "18-23 mo.",
                                        "24-35 mo.",
                                        "over 36 mo."))
co15.a$ILLB_R11_r <- relevel(co15.a$ILLB_R11_r, ref="1st birth")

# PRECARE5_r
unique(co15.a$PRECARE5_r)
co15.a$PRECARE5_r <- factor(co15.a$PRECARE5_r,
                            levels = c( "1st to 3rd month",
                                        "4th to 6th month",
                                        "7th to final month",
                                        "No prenatal care"))
co15.a$PRECARE5_r <- relevel(co15.a$PRECARE5_r, ref="No prenatal care")

# PREVIS_r
unique(co15.a$PREVIS_r)
co15.a$PREVIS_r[co15.a$PREVIS_r == "0"] <- "less than 10"
co15.a$PREVIS_r[co15.a$PREVIS_r == "10-15"] <- "10 or more"
co15.a$PREVIS_r[co15.a$PREVIS_r == "more than 15"] <- "10 or more"
co15.a$PREVIS_r <- factor(co15.a$PREVIS_r,
                          levels = c( "less than 10",
                                      "10 or more"))
co15.a$PREVIS_r <- relevel(co15.a$PREVIS_r, ref="less than 10")

# BMI_R_r
unique(co15.a$BMI_R_r)
co15.a$BMI_R_r <- factor(co15.a$BMI_R_r,
                         levels = c( "Underweight <18.5",
                                     "Normal 18.5-24.9",
                                     "Overweight 25.0-29.9",
                                     "Obesity I 35.0-39.9",
                                     "Obesity II 35.0-39.9",
                                     "Extreme Obesity III >=40.0"))
co15.a$BMI_R_r <- relevel(co15.a$BMI_R_r, ref="Normal 18.5-24.9")

# PAY_r
unique(co15.a$PAY_r)
co15.a$PAY_r <- factor(co15.a$PAY_r,
                       levels = c("Private Insurance/Other", 
                                  "Medicaid/IHS"))
co15.a$PAY_r <- relevel(co15.a$PAY_r, ref="Private Insurance/Other")

# DPLURAL_r
unique(co15.a$DPLURAL_r)
co15.a$DPLURAL_r <- factor(co15.a$DPLURAL_r,
                           levels = c( "Single",
                                       "Multiple"))
co15.a$DPLURAL_r <- relevel(co15.a$DPLURAL_r, ref="Single")

# SEX_r
unique(co15.a$SEX_r)
co15.a$SEX_r <- factor(co15.a$SEX_r,
                       levels = c( "Female",
                                   "Male"))
co15.a$SEX_r <- relevel(co15.a$SEX_r, ref="Female")

# BWTR4_r
unique(co15.a$BWTR4_r)
co15.a$BWTR4_r <- factor(co15.a$BWTR4_r,
                         levels = c( "2500 - 8165 grams",
                                     "1500 - 2499 grams",
                                     "227 - 1499 grams"))
co15.a$BWTR4_r <- relevel(co15.a$BWTR4_r, ref="2500 - 8165 grams")

# ANOMALY
unique(co15.a$ANOMALY)
co15.a$ANOMALY[co15.a$ANOMALY == "ANOMALY"] <- "Yes"
co15.a$ANOMALY <- factor(co15.a$ANOMALY,
                         levels = c("No", "Yes"))
co15.a$ANOMALY <- relevel(co15.a$ANOMALY, ref="No")

# BFED_r
unique(co15.a$BFED_r)
co15.a$BFED_r[co15.a$BFED_r == "BFED_r"] <- "No"
co15.a$BFED_r <- factor(co15.a$BFED_r,
                        levels = c( "Yes",
                                    "No"))
co15.a$BFED_r <- relevel(co15.a$BFED_r, ref="Yes")

# COMBGEST_r
unique(co15.a$COMBGEST_r)
co15.a$COMBGEST_r <- factor(co15.a$COMBGEST_r,
                            levels = c( "under 20 weeks",
                                        "20-24 weeks",
                                        "25-29 weeks",
                                        "30-34 weeks",
                                        "35-36 weeks",
                                        "37-38 weeks",
                                        "39 weeks",
                                        "40 weeks",
                                        "41 weeks",
                                        "over 41 weeks"))
co15.a$COMBGEST_r <- relevel(co15.a$COMBGEST_r, ref="40 weeks")

# ANY_CIG
unique(co15.a$ANY_CIG)
co15.a$ANY_CIG <- factor(co15.a$ANY_CIG,
                         levels = c( "Nonsmoker",
                                     "Smoker",
                                     "Smoker, quit"))
co15.a$ANY_CIG <- relevel(co15.a$ANY_CIG, ref="Nonsmoker")

# CIG1_R_r
unique(co15.a$CIG1_R_r)
co15.a$CIG1_R_r[co15.a$CIG1_R_r == "1-5 cigarettes_CIG1_R_r"] <- "1-5 cigarettes"
co15.a$CIG1_R_r[co15.a$CIG1_R_r == "6-10 cigarettes_CIG1_R_r"] <- "6-10 cigarettes"
co15.a$CIG1_R_r[co15.a$CIG1_R_r == "more than 10 cigarettes_CIG1_R_r"] <- "more than 10 cigarettes"
co15.a$CIG1_R_r <- factor(co15.a$CIG1_R_r,
                          levels = c( "Nonsmoker",
                                      "1-5 cigarettes",
                                      "6-10 cigarettes",
                                      "more than 10 cigarettes"))
co15.a$CIG1_R_r <- relevel(co15.a$CIG1_R_r, ref="Nonsmoker")

# CIG2_R_r
unique(co15.a$CIG2_R_r)
co15.a$CIG2_R_r[co15.a$CIG2_R_r == "1-5 cigarettes_CIG1_R_r"] <- "1-5 cigarettes"
co15.a$CIG2_R_r[co15.a$CIG2_R_r == "6-10 cigarettes_CIG1_R_r"] <- "6-10 cigarettes"
co15.a$CIG2_R_r[co15.a$CIG2_R_r == "more than 10 cigarettes_CIG1_R_r"] <- "more than 10 cigarettes"
co15.a$CIG2_R_r <- factor(co15.a$CIG2_R_r,
                          levels = c( "Nonsmoker",
                                      "1-5 cigarettes",
                                      "6-10 cigarettes",
                                      "more than 10 cigarettes"))
co15.a$CIG2_R_r <- relevel(co15.a$CIG2_R_r, ref="Nonsmoker")

# CIG3_R_r
unique(co15.a$CIG3_R_r)
co15.a$CIG3_R_r[co15.a$CIG3_R_r == "1-5 cigarettes_CIG1_R_r"] <- "1-5 cigarettes"
co15.a$CIG3_R_r[co15.a$CIG3_R_r == "6-10 cigarettes_CIG1_R_r"] <- "6-10 cigarettes"
co15.a$CIG3_R_r[co15.a$CIG3_R_r == "more than 10 cigarettes_CIG1_R_r"] <- "more than 10 cigarettes"
co15.a$CIG3_R_r <- factor(co15.a$CIG3_R_r,
                          levels = c( "Nonsmoker",
                                      "1-5 cigarettes",
                                      "6-10 cigarettes",
                                      "more than 10 cigarettes"))
co15.a$CIG3_R_r <- relevel(co15.a$CIG3_R_r, ref="Nonsmoker")

# uRF_Diab_r
unique(co15.a$uRF_Diab_r)
co15.a$uRF_Diab_r[co15.a$uRF_Diab_r == "uRF_Diab_r"] <- "Yes"
co15.a$uRF_Diab_r <- factor(co15.a$uRF_Diab_r,
                            levels = c("Yes", "No"))
co15.a$uRF_Diab_r <- relevel(co15.a$uRF_Diab_r, ref="No")

# uRF_Chype_r
unique(co15.a$uRF_Chype_r)
co15.a$uRF_Chype_r[co15.a$uRF_Chype_r == "uRF_Chype_r"] <- "Yes"
co15.a$uRF_Chype_r <- factor(co15.a$uRF_Chype_r,
                             levels = c("Yes", "No"))
co15.a$uRF_Chype_r <- relevel(co15.a$uRF_Chype_r, ref="No")

# uRF_Phype_r
unique(co15.a$uRF_Phype_r)
co15.a$uRF_Phype_r[co15.a$uRF_Phype_r == "uRF_Phype_r"] <- "Yes"
co15.a$uRF_Phype_r <- factor(co15.a$uRF_Phype_r,
                             levels = c("Yes", "No"))
co15.a$uRF_Phype_r <- relevel(co15.a$uRF_Phype_r, ref="No")

# uRf_Ehype_r
unique(co15.a$uRf_Ehype_r)
co15.a$uRf_Ehype_r[co15.a$uRf_Ehype_r == "uRf_Ehype_r"] <- "Yes"
co15.a$uRf_Ehype_r <- factor(co15.a$uRf_Ehype_r,
                             levels = c("Yes", "No"))
co15.a$uRf_Ehype_r <- relevel(co15.a$uRf_Ehype_r, ref="No")

# uLD_Bree_r
unique(co15.a$uLD_Bree_r)
co15.a$uLD_Bree_r[co15.a$uLD_Bree_r == "uLD_Bree_r"] <- "Yes"
co15.a$uLD_Bree_r <- factor(co15.a$uLD_Bree_r,
                            levels = c("Yes", "No"))
co15.a$uLD_Bree_r <- relevel(co15.a$uLD_Bree_r, ref="No")

# PRIORDEAD_r
unique(co15.a$PRIORDEAD_r)
co15.a$PRIORDEAD_r[co15.a$PRIORDEAD_r == "1_PRIORDEAD_r"] <- "1"
co15.a$PRIORDEAD_r[co15.a$PRIORDEAD_r == "2_PRIORDEAD_r"] <- "2"
co15.a$PRIORDEAD_r[co15.a$PRIORDEAD_r == "3_PRIORDEAD_r"] <- "3"
co15.a$PRIORDEAD_r[co15.a$PRIORDEAD_r == "more than 3_PRIORDEAD_r"] <- "more than 3"
co15.a$PRIORDEAD_r <- factor(co15.a$PRIORDEAD_r,
                             levels = c( "0",
                                         "1",
                                         "2",
                                         "3",
                                         "more than 3"))
co15.a$PRIORDEAD_r <- relevel(co15.a$PRIORDEAD_r, ref="0")

# PRIORTERM_r
unique(co15.a$PRIORTERM_r)
co15.a$PRIORTERM_r[co15.a$PRIORTERM_r == "1_PRIORTERM_r"] <- "1"
co15.a$PRIORTERM_r[co15.a$PRIORTERM_r == "2_PRIORTERM_r"] <- "2"
co15.a$PRIORTERM_r[co15.a$PRIORTERM_r == "more than 2_PRIORTERM_r"] <- "more than 2"
co15.a$PRIORTERM_r <- factor(co15.a$PRIORTERM_r,
                             levels = c( "0",
                                         "1",
                                         "2",
                                         "more than 2"))
co15.a$PRIORTERM_r <- relevel(co15.a$PRIORTERM_r, ref="0")

# PRIORLIVE_r
unique(co15.a$PRIORLIVE_r)
co15.a$PRIORLIVE_r[co15.a$PRIORLIVE_r == "1_PRIORLIVE_r"] <- "1"
co15.a$PRIORLIVE_r[co15.a$PRIORLIVE_r == "2_PRIORLIVE_r"] <- "2"
co15.a$PRIORLIVE_r[co15.a$PRIORLIVE_r == "3_PRIORLIVE_r"] <- "3"
co15.a$PRIORLIVE_r[co15.a$PRIORLIVE_r == "4_PRIORLIVE_r"] <- "4"
co15.a$PRIORLIVE_r[co15.a$PRIORLIVE_r == "5_PRIORLIVE_r"] <- "5"
co15.a$PRIORLIVE_r[co15.a$PRIORLIVE_r == "6_PRIORLIVE_r"] <- "6"
co15.a$PRIORLIVE_r[co15.a$PRIORLIVE_r == "more than 6_PRIORLIVE_r"] <- "more than 6"
co15.a$PRIORLIVE_r <- factor(co15.a$PRIORLIVE_r,
                             levels = c( "0",
                                         "1",
                                         "2",
                                         "3",
                                         "4",
                                         "5",
                                         "6",
                                         "more than 6"))
co15.a$PRIORLIVE_r <- relevel(co15.a$PRIORLIVE_r, ref="0")



sapply(lapply(co15.a, unique), length)



#################################################
#################################################
# Forward Stepwise Regression
#################################################
#################################################

# since log_m2 uses all the variables in the model, we can use this as the most general
# model for fitting the stepwise regression.

# forward stepwise regression (constrained to include DMAR_r, ANY_CIG, and BMI_R_r)
#stepreg1 <- stepAIC(log_m2, direction = "forward",
#                   scope=list(upper = ~ ., lower = ~ 1 + DMAR_r + ANY_CIG + BMI_R_r))

# forward stepwise regression with 1st-order interactions (constrained to include DMAR_r, ANY_CIG, and BMI_R_r)
#stepreg2 <- stepAIC(log_m2, direction = "forward",
#                  scope=list(upper = ~ .^2, lower = ~ 1 + DMAR_r + ANY_CIG + BMI_R_r))





################################################################################
# Grouped LASSO Selected Model
################################################################################
# Convert Response to Binomial Coding
selected_grouped <- co15.a %>%
  group_by(APGAR5_r, DMAR_r, PREVIS_r, ANY_CIG, BWTR4_r, ANOMALY, BFED_r, 
           COMBGEST_r, uLD_Bree_r, BMI_R_r) %>%
  summarize(ndied = sum(DIED),
            nalive = n() - ndied) %>%
  ungroup()

# Fit logistic regression model using binomial response coding
log_m1.b <- glm(cbind(ndied, nalive) ~ 
                  APGAR5_r +
                  DMAR_r +
                  PREVIS_r +
                  ANY_CIG +
                  BWTR4_r +
                  ANOMALY +
                  BFED_r +
                  COMBGEST_r +
                  uLD_Bree_r +
                  BMI_R_r, 
                data = selected_grouped,
                family = binomial())
summary(log_m1.b)

# test for overdispersion
deviance(log_m1.b) / df.residual(log_m1.b)

# plot standardized deviance residuals vs. n_i
m1.resid.plot <- ggplot(data.frame(resid=rstandard(log_m1.b), 
                                   n_i=rowSums(selected_grouped[,c("ndied", "nalive")])),
                        aes(x=n_i, y=resid)) + 
                  geom_point(shape=1) + 
                  ylab("Standardized Deviance Residuals") + 
                  xlab("Group Size")
m1.resid.plot
# residuals have increasing magnitude for increasing values of n_i, thus
# beta-binomial model is preferable.

############################################
# Quasi-binomial Model: Grp LASSO selected
############################################
qb <- glm(cbind(ndied, nalive) ~ ., data = selected_grouped, 
          family = quasibinomial(link='logit'))
summary(qb)

#qb1 <- update(log_m1, family = quasibinomial(link='logit'))

# adjusted odds ratios
adjOR_qb <- exp(cbind(OR=coef(qb), confint(qb)))


############################################
# Beta-Binomial Regression Model: Grp LASSO selected
############################################

bbm <- betabin(cbind(ndied, nalive) ~ ., ~ 1, data=selected_grouped, link="logit", 
               control=list(maxit=5000))
summary(bbm)


# adjusted odds ratios (Wald CIs)
bbm.lb <- as.numeric(coef(bbm)) - qnorm(0.957)*summary(bbm)@Coef[,"Std. Error"]
bbm.ub <- as.numeric(coef(bbm)) + qnorm(0.957)*summary(bbm)@Coef[,"Std. Error"]
adjOR_bbm <- exp(cbind(OR=coef(bbm), CI_LB=bbm.lb, CI_UB=bbm.ub))






################################################################################
# AIC Selected Model
################################################################################
selected_grouped.aic <- co15.a %>%
  group_by(DMAR_r,  ANY_CIG,  BMI_R_r,  BFACIL_r,  MAGER9_r,  MBSTATE_REC_r,  
           MRACE6_r,  MEDUC_r,  ILLB_R11_r,  PRECARE5_r, PREVIS_r, uRF_Chype_r,  
           uRF_Phype_r,  uLD_Bree_r,  PAY_r,  DPLURAL_r,  SEX_r,  BWTR4_r,  BFED_r,  
           ANOMALY,  PRIORDEAD_r,  COMBGEST_r,  APGAR5_r) %>%
  summarize(ndied = sum(DIED),
            nalive = n() - ndied) %>%
  ungroup()


# Fit logistic regression model using binomial response coding
log_aic.b <- glm(cbind(ndied, nalive) ~ 
                   DMAR_r + 
                   ANY_CIG + 
                   BMI_R_r + 
                   BFACIL_r + 
                   MAGER9_r + 
                   MBSTATE_REC_r + 
                   MRACE6_r + 
                   MEDUC_r + 
                   ILLB_R11_r + 
                   PRECARE5_r + 
                   PREVIS_r + 
                   uRF_Chype_r + 
                   uRF_Phype_r + 
                   uLD_Bree_r + 
                   PAY_r + 
                   DPLURAL_r + 
                   SEX_r + 
                   BWTR4_r + 
                   BFED_r + 
                   ANOMALY + 
                   PRIORDEAD_r + 
                   COMBGEST_r + 
                   APGAR5_r, 
                 data = selected_grouped.aic,
                 family = binomial())
summary(log_aic.b)

# test for overdispersion
deviance(log_aic.b) / df.residual(log_aic.b)

# plot standardized deviance residuals vs. n_i
m2.resid.plot <- ggplot(data.frame(resid=rstandard(log_aic.b), 
                                   n_i=rowSums(selected_grouped.aic[,c("ndied", "nalive")])),
                        aes(x=n_i, y=resid)) + 
  geom_point(shape=1)
m2.resid.plot
# residuals have increasing magnitude for increasing values of n_i, thus
# beta-binomial model is preferable.


############################################
# Quasi-binomial Model: AIC selected
############################################

qb.aic <- glm(cbind(ndied, nalive) ~ ., data = selected_grouped.aic, 
              family = quasibinomial(link='logit'))
summary(qb.aic)

# adjusted odds ratios
adjOR_qb.aic <- exp(cbind(OR=coef(qb.aic), confint(qb.aic)))



###########################################
# Beta-Binomial Regression Model: AIC selected
############################################

bbm.aic <- betabin(cbind(ndied, nalive) ~ ., ~ 1, data=selected_grouped.aic, link="logit")
summary(bbm.aic)


# adjusted odds ratios (Wald CIs)
bbm.aiclb <- as.numeric(coef(bbm.aic)) - qnorm(0.957)*summary(bbm.aic)@Coef[,"Std. Error"]
bbm.aicub <- as.numeric(coef(bbm.aic)) + qnorm(0.957)*summary(bbm.aic)@Coef[,"Std. Error"]
adjOR_bbm.aic <- exp(cbind(OR=coef(bbm.aic), CI_LB=bbm.aiclb, CI_UB=bbm.aicub))




save.image("~/Academic/Case Studies in Data Analysis (STAT 634)/Infant Mortality Project/CS2_infant_mortality_study/CS2_logistic2.RData")





################################################################################
# BIC Selected Model
################################################################################

selected_grouped.sc <- co15.a %>%
  group_by(DMAR_r, ANY_CIG, BMI_R_r, MAGER9_r, ILLB_R11_r, PRECARE5_r, PREVIS_r, 
           uLD_Bree_r, SEX_r, BWTR4_r, BFED_r, ANOMALY, COMBGEST_r, APGAR5_r) %>%
  summarize(ndied = sum(DIED),
            nalive = n() - ndied) %>%
  ungroup()

# Fit logistic regression model using binomial response coding
log_sc.b <- glm(cbind(ndied, nalive) ~ 
                  DMAR_r + 
                  ANY_CIG	+ 	
                  BMI_R_r	+ 	
                  MAGER9_r + 	
                  ILLB_R11_r + 
                  PRECARE5_r + 
                  PREVIS_r + 
                  uLD_Bree_r + 
                  SEX_r + 
                  BWTR4_r + 
                  BFED_r + 
                  ANOMALY + 
                  COMBGEST_r + 
                  APGAR5_r, 
                data = selected_grouped.sc,
                family = binomial())
summary(log_sc.b)

# test for overdispersion
deviance(log_sc.b) / df.residual(log_sc.b)

# plot standardized deviance residuals vs. n_i
m3.resid.plot <- ggplot(data.frame(resid=rstandard(log_sc.b), 
                                   n_i=rowSums(selected_grouped.sc[,c("ndied", "nalive")])),
                        aes(x=n_i, y=resid)) + 
                      geom_point(shape=1) + 
                      ylab("Standardized Deviance Residuals") + 
                      xlab("Group Size")
m3.resid.plot
# residuals have increasing magnitude for increasing values of n_i, thus
# beta-binomial model is preferable.


############################################
# Quasi-binomial Model: BIC selected
############################################

qb.sc <- glm(cbind(ndied, nalive) ~ ., data = selected_grouped.sc, 
             family = quasibinomial(link='logit'))
summary(qb.sc)

# qb.bic <- update(log_SC, family = quasibinomial(link='logit'))

# adjusted odds ratios
adjOR_qb.sc <- exp(cbind(OR=coef(qb.sc), confint(qb.sc)))



############################################
# Beta-Binomial Regression Model: BIC selected
############################################

bbm.sc <- betabin(cbind(ndied, nalive) ~ ., ~ 1, 
                  data=selected_grouped.sc, link="logit", na.action=na.omit)
summary(bbm.sc)


# adjusted odds ratios (Wald CIs)
bbm.sclb <- as.numeric(coef(bbm.sc)) - qnorm(0.957)*summary(bbm.sc)@Coef[,"Std. Error"]
bbm.scub <- as.numeric(coef(bbm.sc)) + qnorm(0.957)*summary(bbm.sc)@Coef[,"Std. Error"]
adjOR_bbm.sc <- exp(cbind(OR=coef(bbm.sc), CI_LB=bbm.sclb, CI_UB=bbm.scub))







################################################################################
# 5-Step Selected Model
################################################################################
selected_grouped.simp <- co15.a %>%
  group_by(DMAR_r, ANY_CIG, BMI_R_r, BWTR4_r, BFED_r, ANOMALY, COMBGEST_r, APGAR5_r) %>%
  summarize(ndied = sum(DIED),
            nalive = n() - ndied) %>%
  ungroup()

# Fit logistic regression model using binomial response coding
log_simp.b <- glm(cbind(ndied, nalive) ~ ., 
                  data = selected_grouped.simp,
                  family = binomial())
summary(log_simp.b)

# test for overdispersion
deviance(log_simp.b) / df.residual(log_simp.b)

# plot standardized deviance residuals vs. n_i
m4.resid.plot <- ggplot(data.frame(resid=rstandard(log_simp.b), 
                                   n_i=rowSums(selected_grouped.simp[,c("ndied", "nalive")])),
                        aes(x=n_i, y=resid)) + 
  geom_point(shape=1)
m4.resid.plot
# residuals have increasing magnitude for increasing values of n_i, thus
# beta-binomial model is preferable.


############################################
# Quasi-binomial Model: 5-Step Selected
############################################

qb.simp <- glm(cbind(ndied, nalive) ~ ., data = selected_grouped.simp, 
               family = quasibinomial(link='logit'))
summary(qb.simp)


# adjusted odds ratios
adjOR_qb.simp <- exp(cbind(OR=coef(qb.simp), confint(qb.simp)))



save.image("~/Academic/Case Studies in Data Analysis (STAT 634)/Infant Mortality Project/CS2_infant_mortality_study/CS2_logistic2.RData")





################################################################################
# Grouped LASSO with Minimum Cross-Validated Error
################################################################################

selected_grouped.all <- co15.a %>%
  group_by(APGAR5_r, BFACIL_r, MAGER9_r, MBSTATE_REC_r, MRACE6_r, DMAR_r, MEDUC_r, 
           TBO_REC_r, ILLB_R11_r, PRECARE5_r, PREVIS_r, ANY_CIG, PAY_r, DPLURAL_r, 
           SEX_r, BWTR4_r, ANOMALY, BFED_r, COMBGEST_r, CIG1_R_r, CIG2_R_r, CIG3_R_r, 
           uRF_Diab_r, uRF_Chype_r, uRF_Phype_r, uRf_Ehype_r, uLD_Bree_r, PRIORLIVE_r, 
           PRIORDEAD_r, PRIORTERM_r, BMI_R_r) %>%
  summarize(ndied = sum(DIED),
            nalive = n() - ndied) %>%
  ungroup()

sapply(lapply(selected_grouped.all, unique), length)


# Fit logistic regression model using binomial response coding
log_all.b <- glm(cbind(ndied, nalive) ~ 
                   APGAR5_r + 
                   BFACIL_r + 
                   MAGER9_r + 
                   MBSTATE_REC_r + 
                   MRACE6_r + 
                   DMAR_r + 
                   MEDUC_r + 
                   TBO_REC_r + 
                   ILLB_R11_r + 
                   PRECARE5_r + 
                   PREVIS_r + 
                   ANY_CIG + 
                   PAY_r + 
                   DPLURAL_r + 
                   SEX_r + 
                   BWTR4_r + 
                   ANOMALY + 
                   BFED_r + 
                   COMBGEST_r + 
                   CIG1_R_r + 
                   CIG2_R_r + 
                   CIG3_R_r + 
                   uRF_Diab_r + 
                   uRF_Chype_r + 
                   uRF_Phype_r + 
                   uRf_Ehype_r + 
                   uLD_Bree_r + 
                   PRIORLIVE_r + 
                   PRIORDEAD_r + 
                   PRIORTERM_r + 
                   BMI_R_r, 
                 data = selected_grouped.all,
                 family = binomial())
summary(log_all.b)

# test for overdispersion
deviance(log_all.b) / df.residual(log_all.b)

# plot standardized deviance residuals vs. n_i
m5.resid.plot <- ggplot(data.frame(resid=rstandard(log_all.b), 
                                   n_i=rowSums(selected_grouped.all[,c("ndied", "nalive")])),
                        aes(x=n_i, y=resid)) + 
  geom_point(shape=1)
m5.resid.plot
# residuals have increasing magnitude for increasing values of n_i, thus
# beta-binomial model is preferable.


############################################
# Quasi-binomial Model: All
############################################

qb.all <- glm(cbind(ndied, nalive) ~ ., data = selected_grouped.all, 
              family = quasibinomial(link='logit'))
summary(qb.all)


# adjusted odds ratios
#adjOR_qb.all <- exp(cbind(OR=coef(qb.all), confint(qb.all)))

save.image("~/Academic/Case Studies in Data Analysis (STAT 634)/Infant Mortality Project/CS2_infant_mortality_study/CS2_logistic2.RData")





################################################################################
# Model Comparison
################################################################################

#################################################
# Compare Logistic Models
#################################################
# BIC
extractAIC(log_m1.b, k=log(nrow(selected_grouped)))
extractAIC(log_aic.b, k=log(nrow(selected_grouped.aic)))
extractAIC(log_sc.b, k=log(nrow(selected_grouped.sc)))
extractAIC(log_simp.b, k=log(nrow(selected_grouped.simp)))

#AIC
extractAIC(log_m1.b, k=2)
extractAIC(log_aic.b, k=2)
extractAIC(log_sc.b, k=2)
extractAIC(log_simp.b, k=2)


#################################################
# Compare Quasi-binomial Models
# estimate training error when full data is used to train model
#################################################

# LASSO Selected Model
response.probs.qb <- selected_grouped$ndied/(selected_grouped$ndied + selected_grouped$nalive)
mean((response.probs.qb - qb$fitted.values)^2)

# AIC Selected Model
response.probs.qb.aic <- selected_grouped.aic$ndied/(selected_grouped.aic$ndied + selected_grouped.aic$nalive)
mean((response.probs.qb.aic - qb.aic$fitted.values)^2)

# BIC Selected Model
response.probs.qb.sc <- selected_grouped.sc$ndied/(selected_grouped.sc$ndied + selected_grouped.sc$nalive)
mean((response.probs.qb.sc - qb.sc$fitted.values)^2)

# 5-Step Selected Model
response.probs.qb5 <- selected_grouped.simp$ndied/(selected_grouped.simp$ndied + selected_grouped.simp$nalive)
mean((response.probs.qb5 - qb.simp$fitted.values)^2)



#################################################
# Estimate Test Error for Models
# using 5-Fold Cross-Validation
#################################################

# Group LASSO Selected Model
set.seed(7)
cv.lasso.qb <- cv.glm(selected_grouped, qb, K=5)
cv.lasso.qb$delta   


# AIC Selected Model
set.seed(7)
cv.aic.qb <- cv.glm(selected_grouped.aic, qb.aic, K=5)
cv.aic.qb$delta


# BIC Selected Model
set.seed(7)
cv.sc.qb <- cv.glm(selected_grouped.sc, qb.sc, K=5)
cv.sc.qb$delta


# 5-Step Selected Model
set.seed(7)
cv.simp.qb <- cv.glm(selected_grouped.simp, qb.simp, K=5)
cv.simp.qb$delta


# 5-Step Selected Model
set.seed(7)
cv.all.qb <- cv.glm(selected_grouped.all, qb.all, K=5)
cv.all.qb$delta




################################################################################
# Structural Equation Model
################################################################################

#########################################
# Greedy Equivalence Search Algorithm
#########################################

co15.matrix <- co15.a %>% 
  dplyr::select(DIED, DMAR_r,  ANY_CIG,  BMI_R_r,  BFACIL_r,  MAGER9_r,  MBSTATE_REC_r,  
                 MRACE6_r,  MEDUC_r,  ILLB_R11_r,  PRECARE5_r, PREVIS_r, uRF_Chype_r,  
                 uRF_Phype_r,  uLD_Bree_r,  PAY_r,  DPLURAL_r,  SEX_r,  BWTR4_r,  BFED_r,  
                 ANOMALY,  PRIORDEAD_r,  COMBGEST_r,  APGAR5_r)

for (j in 1:ncol(co15.matrix)) {
  co15.matrix[,j] <- as.numeric(co15.matrix[,j])
}


# Define AIC score criterion for algorithm
score <- new("GaussL0penObsScore", co15.matrix,
             lambda = 0.5*log(nrow(co15.matrix)),
             intercept = TRUE,
             use.cpp = TRUE)

# GES algorithm
ges.qic.qb <- ges(score, labels=colnames(co15.matrix))

# no. of edges
getGraph(ges.qic.qb$essgraph)


# Plot Graph
if (require(Rgraphviz)) {
  par(mfrow = c(1,1))
  plot(ges.qic.qb$essgraph, main = "Estimated CPDAG")
}


# Connections
as(as(ges.qic.qb$essgraph,"graphNEL"),"Matrix")



#########################################
# PC Algorithm
#########################################

# number of levels for variables
numlev <- as.numeric(sapply(lapply(co15.matrix, unique), length))


# PC algorithm
pc.aic.qb <- pc(suffStat = list(dm=co15.matrix, nlev=numlev, adaptDF=FALSE),
                  indepTest = disCItest,
                  alpha = 0.05,
                  labels = colnames(co15.matrix),
                  skel.method = "stable",
                  maj.rule = TRUE,
                  verbose = TRUE)

# no. of edges
getGraph(pc.aic.qb)





save.image("~/Academic/Case Studies in Data Analysis (STAT 634)/Infant Mortality Project/CS2_infant_mortality_study/CS2_logistic2.RData")

# Plot graph
if (require(Rgraphviz)) {
  plot(pc.aic.qb, main = "Estimated CPDAG")
}

rm(list = ls())

