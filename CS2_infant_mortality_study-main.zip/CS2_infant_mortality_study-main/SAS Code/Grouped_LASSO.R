#                       STAT 634 - CASE STUDY 2

################################################################################
#               Grouped LASSO for Variable Selection
################################################################################
# coded by: Jonathan Abbamonte

# load libraries
library(haven)
library(tidyverse)
library(grplasso)
library(SGL)
library(pROC)
library(grpreg)
library(survival)


#################################################
# Load Dataset
#################################################
co15 <- read_sas("Data/co15.sas7bdat")

# all variables in dataset
colnames(co15)

# Subset dataset to recoded variables to be fitted to the model
co15.s <- co15 %>% 
  dplyr::select(BFACIL_r,
                MAGER9_r,
                MBSTATE_REC_r,
                MRACE6_r,
                MRACEHISP_r,
                DMAR_r,
                MEDUC_r,
                FAGE11_r,
                FRACEHISP_r,
                FEDUC_r,
                TBO_REC_r,
                ILLB_R11_r,
                PRECARE5_r,
                PREVIS_r,
                BMI_rC,
                BMI_R_r,
                PAY_r,
                APGAR5_r,
                DPLURAL_r,
                SEX_r,
                BWTR4_r,
                ANOMALY,
                BFED_r,
                COMBGEST_r,
                ANY_CIG,
                CIG1_R_r,
                CIG2_R_r,
                CIG3_R_r,
                uRF_Diab_r,
                uRF_Chype_r,
                uRF_Phype_r,
                uRf_Ehype_r,
                uLD_Bree_r,
                PRIORDEAD_r,
                PRIORTERM_r,
                PRIORLIVE_r,
                uCA_Anen_r,
                uCA_Spina_r,
                uCA_Omph_r,
                uCA_Hern_r,
                uCA_Down_r,
                BRTHWGT_r,
                COMBGEST,
                
                AGER5_r,
                AGED,
                DIED
  )

# Export CO15.s to CSV
write.csv(co15.s, file="Data/co15_r.csv", row.names=FALSE)

# Import CSV for leaner dataset w/o attrib names
co15.s <- read.csv("Data/co15_r.csv", header=TRUE)
#co15.s <- co15.l



#################################################
# Recoding
#################################################
# convert categorical variables to factors
# BFACIL_r
unique(co15.s$BFACIL_r)
co15.s$BFACIL_r <- factor(co15.s$BFACIL_r,
                          levels = c( "Hospital",
                                      "Home(intended)/Birth Center",
                                      "Other"))
# MAGER9_r
unique(co15.s$MAGER9_r)
co15.s$MAGER9_r <- factor(co15.s$MAGER9_r,
                          levels = c("Under 15 years",
                                     "15-19 years",
                                     "20-24 years",
                                     "25-29 years",
                                     "30-34 years",
                                     "35-39 years",
                                     "40-44 years",
                                     "45-49 years",
                                     "50-54 years"))
co15.s$MAGER9_r <- relevel(co15.s$MAGER9_r, ref="20-24 years")

# MBSTATE_REC_r
unique(co15.s$MBSTATE_REC_r)
co15.s$MBSTATE_REC_r <- factor(co15.s$MBSTATE_REC_r,
                               levels = c("Born in the U.S.",
                                          "Born outside the U.S."))
co15.s$MBSTATE_REC_r <- relevel(co15.s$MBSTATE_REC_r, ref="Born in the U.S.")

# MRACE6_r
unique(co15.s$MRACE6_r)
co15.s$MRACE6_r <- factor(co15.s$MRACE6_r,
                          levels = c(  "White (only)",
                                       "Black (only)",
                                       "AIAN/NHOPI",
                                       "Asian (only)",
                                       "More than one race"))
co15.s$MRACE6_r <- relevel(co15.s$MRACE6_r, ref="White (only)")

# MRACEHISP_r
unique(co15.s$MRACEHISP_r)
co15.s$MRACEHISP_r <- factor(co15.s$MRACEHISP_r,
                             levels = c( "White",
                                         "Black",
                                         "AIAN/NHOPI",
                                         "Asian",
                                         "Hispanic",
                                         "more than one race"))
co15.s$MRACEHISP_r <- relevel(co15.s$MRACEHISP_r, ref="White")

# DMAR_r
unique(co15.s$DMAR_r)
co15.s$DMAR_r <- factor(co15.s$DMAR_r,
                        levels = c("Married", "Unmarried"))
co15.s$DMAR_r <- relevel(co15.s$DMAR_r, ref="Married")

# MEDUC_r
unique(co15.s$MEDUC_r)
co15.s$MEDUC_r <- factor(co15.s$MEDUC_r,
                         levels = c( "8th grade or less",
                                     "9th-12th grade, no diploma",
                                     "High school diploma",
                                     "Some college, no degree",
                                     "Associate degree",
                                     "Bachelor's degree",
                                     "Master's degree",
                                     "Doctorate/Professional"))
co15.s$MEDUC_r <- relevel(co15.s$MEDUC_r, ref="High school diploma")

# FAGE11_r
unique(co15.s$FAGE11_r)
co15.s$FAGE11_r <- factor(co15.s$FAGE11_r, 
                          levels = c("Under 15 yea",
                                     "15-19 years",
                                     "20-24 years",
                                     "25-29 years",
                                     "30-34 years",
                                     "35-39 years",
                                     "40-44 years",
                                     "45-49 years",
                                     "50-54 years"))
co15.s$FAGE11_r <- relevel(co15.s$FAGE11_r, ref="20-24 years")

# FRACEHISP_r
unique(co15.s$FRACEHISP_r)
co15.s$FRACEHISP_r <- factor(co15.s$FRACEHISP_r,
                             levels = c( "White",
                                         "Black",
                                         "AIAN/NHOPI",
                                         "Asian",
                                         "Hispanic",
                                         "more than one race"))
co15.s$FRACEHISP_r <- relevel(co15.s$FRACEHISP_r, ref="White")

# FEDUC_r
unique(co15.s$FEDUC_r)
co15.s$FEDUC_r <- factor(co15.s$FEDUC_r,
                         levels = c( "8th grade or less",
                                     "9th-12th grade, no diploma",
                                     "High school diploma",
                                     "Some college, no degree",
                                     "Associate degree",
                                     "Bachelor's degree",
                                     "Master's degree",
                                     "Doctorate/Professional"))
co15.s$FEDUC_r <- relevel(co15.s$FEDUC_r, ref="High school diploma")

# ILLB_R11_r
unique(co15.s$ILLB_R11_r)
co15.s$ILLB_R11_r <- factor(co15.s$ILLB_R11_r,
                            levels = c( "1st birth",
                                        "0-3 mo.",
                                        "4-11 mo.",
                                        "12-17 mo.",
                                        "18-23 mo.",
                                        "24-35 mo.",
                                        "over 36 mo."))
co15.s$ILLB_R11_r <- relevel(co15.s$ILLB_R11_r, ref="1st birth")

# PRECARE5_r
unique(co15.s$PRECARE5_r)
co15.s$PRECARE5_r <- factor(co15.s$PRECARE5_r,
                            levels = c( "1st to 3rd month",
                                        "4th to 6th month",
                                        "7th to final month",
                                        "No prenatal care"))
co15.s$PRECARE5_r <- relevel(co15.s$PRECARE5_r, ref="No prenatal care")

# ANOMALY
unique(co15.s$ANOMALY)
co15.s$ANOMALY[co15.s$ANOMALY == "Yes"] <- "ANOMALY"
co15.s$ANOMALY <- factor(co15.s$ANOMALY,
                         levels = c("No", "ANOMALY"))
co15.s$ANOMALY <- relevel(co15.s$ANOMALY, ref="No")

# CIG1_R_r
unique(co15.s$CIG1_R_r)
co15.s$CIG1_R_r[co15.s$CIG1_R_r == "1-5 cigarettes"] <- "1-5 cigarettes_CIG1_R_r"
co15.s$CIG1_R_r[co15.s$CIG1_R_r == "6-10 cigarettes"] <- "6-10 cigarettes_CIG1_R_r"
co15.s$CIG1_R_r[co15.s$CIG1_R_r == "more than 10 cigarettes"] <- "more than 10 cigarettes_CIG1_R_r"
co15.s$CIG1_R_r <- factor(co15.s$CIG1_R_r,
                          levels = c( "Nonsmoker",
                                      "1-5 cigarettes_CIG1_R_r",
                                      "6-10 cigarettes_CIG1_R_r",
                                      "more than 10 cigarettes_CIG1_R_r"))
co15.s$CIG1_R_r <- relevel(co15.s$CIG1_R_r, ref="Nonsmoker")

# CIG2_R_r
unique(co15.s$CIG2_R_r)
co15.s$CIG2_R_r[co15.s$CIG2_R_r == "1-5 cigarettes"] <- "1-5 cigarettes_CIG2_R_r"
co15.s$CIG2_R_r[co15.s$CIG2_R_r == "6-10 cigarettes"] <- "6-10 cigarettes_CIG2_R_r"
co15.s$CIG2_R_r[co15.s$CIG2_R_r == "more than 10 cigarettes"] <- "more than 10 cigarettes_CIG2_R_r"
co15.s$CIG2_R_r <- factor(co15.s$CIG2_R_r,
                          levels = c( "Nonsmoker",
                                      "1-5 cigarettes_CIG2_R_r",
                                      "6-10 cigarettes_CIG2_R_r",
                                      "more than 10 cigarettes_CIG2_R_r"))
co15.s$CIG2_R_r <- relevel(co15.s$CIG2_R_r, ref="Nonsmoker")

# CIG3_R_r
unique(co15.s$CIG3_R_r)
co15.s$CIG3_R_r[co15.s$CIG3_R_r == "1-5 cigarettes"] <- "1-5 cigarettes_CIG3_R_r"
co15.s$CIG3_R_r[co15.s$CIG3_R_r == "6-10 cigarettes"] <- "6-10 cigarettes_CIG3_R_r"
co15.s$CIG3_R_r[co15.s$CIG3_R_r == "more than 10 cigarettes"] <- "more than 10 cigarettes_CIG3_R_r"
co15.s$CIG3_R_r <- factor(co15.s$CIG3_R_r,
                          levels = c( "Nonsmoker",
                                      "1-5 cigarettes_CIG3_R_r",
                                      "6-10 cigarettes_CIG3_R_r",
                                      "more than 10 cigarettes_CIG3_R_r"))
co15.s$CIG3_R_r <- relevel(co15.s$CIG3_R_r, ref="Nonsmoker")

# ANY_CIG
unique(co15.s$ANY_CIG)
co15.s$ANY_CIG <- factor(co15.s$ANY_CIG,
                         levels = c( "Nonsmoker",
                                     "Smoker",
                                     "Smoker, quit"))
co15.s$ANY_CIG <- relevel(co15.s$ANY_CIG, ref="Nonsmoker")

# BMI_R_r
unique(co15.s$BMI_R_r)
co15.s$BMI_R_r <- factor(co15.s$BMI_R_r,
                         levels = c( "Underweight <18.5",
                                     "Normal 18.5-24.9",
                                     "Overweight 25.0-29.9",
                                     "Obesity I 35.0-39.9",
                                     "Obesity II 35.0-39.9",
                                     "Extreme Obesity III >=40.0"))
co15.s$BMI_R_r <- relevel(co15.s$BMI_R_r, ref="Normal 18.5-24.9")

# uRF_Diab_r
unique(co15.s$uRF_Diab_r)
co15.s$uRF_Diab_r[co15.s$uRF_Diab_r == "Yes"] <- "uRF_Diab_r"
co15.s$uRF_Diab_r <- factor(co15.s$uRF_Diab_r,
                            levels = c("uRF_Diab_r", "No"))
co15.s$uRF_Diab_r <- relevel(co15.s$uRF_Diab_r, ref="No")

# uRF_Chype_r
unique(co15.s$uRF_Chype_r)
co15.s$uRF_Chype_r[co15.s$uRF_Chype_r == "Yes"] <- "uRF_Chype_r"
co15.s$uRF_Chype_r <- factor(co15.s$uRF_Chype_r,
                             levels = c("uRF_Chype_r", "No"))
co15.s$uRF_Chype_r <- relevel(co15.s$uRF_Chype_r, ref="No")

# uRF_Phype_r
unique(co15.s$uRF_Phype_r)
co15.s$uRF_Phype_r[co15.s$uRF_Phype_r == "Yes"] <- "uRF_Phype_r"
co15.s$uRF_Phype_r <- factor(co15.s$uRF_Phype_r,
                             levels = c("uRF_Phype_r", "No"))
co15.s$uRF_Phype_r <- relevel(co15.s$uRF_Phype_r, ref="No")

# uRf_Ehype_r
unique(co15.s$uRf_Ehype_r)
co15.s$uRf_Ehype_r[co15.s$uRf_Ehype_r == "Yes"] <- "uRf_Ehype_r"
co15.s$uRf_Ehype_r <- factor(co15.s$uRf_Ehype_r,
                             levels = c("uRf_Ehype_r", "No"))
co15.s$uRf_Ehype_r <- relevel(co15.s$uRf_Ehype_r, ref="No")

# uLD_Bree_r
unique(co15.s$uLD_Bree_r)
co15.s$uLD_Bree_r[co15.s$uLD_Bree_r == "Yes"] <- "uLD_Bree_r"
co15.s$uLD_Bree_r <- factor(co15.s$uLD_Bree_r,
                            levels = c("uLD_Bree_r", "No"))
co15.s$uLD_Bree_r <- relevel(co15.s$uLD_Bree_r, ref="No")

# PAY_r
unique(co15.s$PAY_r)
co15.s$PAY_r <- factor(co15.s$PAY_r,
                       levels = c("Private Insurance/Other", 
                                  "Medicaid/IHS"))
co15.s$PAY_r <- relevel(co15.s$PAY_r, ref="Private Insurance/Other")

# DPLURAL_r
unique(co15.s$DPLURAL_r)
co15.s$DPLURAL_r <- factor(co15.s$DPLURAL_r,
                           levels = c( "Single",
                                       "Multiple"))
co15.s$DPLURAL_r <- relevel(co15.s$DPLURAL_r, ref="Single")

# SEX_r
unique(co15.s$SEX_r)
co15.s$SEX_r <- factor(co15.s$SEX_r,
                       levels = c( "Female",
                                   "Male"))
co15.s$SEX_r <- relevel(co15.s$SEX_r, ref="Female")

# BWTR4_r
unique(co15.s$BWTR4_r)
co15.s$BWTR4_r <- factor(co15.s$BWTR4_r,
                         levels = c( "2500 - 8165 grams",
                                     "1500 - 2499 grams",
                                     "227 - 1499 grams"))
co15.s$BWTR4_r <- relevel(co15.s$BWTR4_r, ref="2500 - 8165 grams")

# BFED_r
unique(co15.s$BFED_r)
co15.s$BFED_r[co15.s$BFED_r == "No"] <- "BFED_r"
co15.s$BFED_r <- factor(co15.s$BFED_r,
                        levels = c( "Yes",
                                    "BFED_r"))
co15.s$BFED_r <- relevel(co15.s$BFED_r, ref="Yes")

# TBO_REC_r
unique(co15.s$TBO_REC_r)
co15.s$TBO_REC_r <- factor(co15.s$TBO_REC_r,
                           levels = c( "1 total birth order",
                                       "2 total birth order",
                                       "3 total birth order",
                                       "4 total birth order",
                                       "5 total birth order",
                                       "6 total birth order",
                                       "7 or more total births"))
co15.s$TBO_REC_r <- relevel(co15.s$TBO_REC_r, ref="1 total birth order")

# uCA_Anen_r
unique(co15.s$uCA_Anen_r)
co15.s$uCA_Anen_r[co15.s$uCA_Anen_r == "Yes"] <- "uCA_Anen_r"
co15.s$uCA_Anen_r <- factor(co15.s$uCA_Anen_r,
                            levels = c("No", "uCA_Anen_r"))
co15.s$uCA_Anen_r <- relevel(co15.s$uCA_Anen_r, ref="No")

# uCA_Spina_r
unique(co15.s$uCA_Spina_r)
co15.s$uCA_Spina_r[co15.s$uCA_Spina_r == "Yes"] <- "uCA_Spina_r"
co15.s$uCA_Spina_r <- factor(co15.s$uCA_Spina_r,
                             levels = c("No", "uCA_Spina_r"))
co15.s$uCA_Spina_r <- relevel(co15.s$uCA_Spina_r, ref="No")

# uCA_Omph_r
unique(co15.s$uCA_Omph_r)
co15.s$uCA_Omph_r[co15.s$uCA_Omph_r == "Yes"] <- "uCA_Omph_r"
co15.s$uCA_Omph_r <- factor(co15.s$uCA_Omph_r,
                            levels = c("No", "uCA_Omph_r"))
co15.s$uCA_Omph_r <- relevel(co15.s$uCA_Omph_r, ref="No")

# uCA_Hern_r
unique(co15.s$uCA_Hern_r)
co15.s$uCA_Hern_r[co15.s$uCA_Hern_r == "Yes"] <- "uCA_Hern_r"
co15.s$uCA_Hern_r <- factor(co15.s$uCA_Hern_r,
                            levels = c("No", "uCA_Hern_r"))
co15.s$uCA_Hern_r <- relevel(co15.s$uCA_Hern_r, ref="No")

# uCA_Down_r
unique(co15.s$uCA_Down_r)
co15.s$uCA_Down_r[co15.s$uCA_Down_r == "Yes"] <- "uCA_Down_r"
co15.s$uCA_Down_r <- factor(co15.s$uCA_Down_r,
                            levels = c("No", "uCA_Down_r"))
co15.s$uCA_Down_r <- relevel(co15.s$uCA_Down_r, ref="No")


# PRIORLIVE_r
unique(co15.s$PRIORLIVE_r)
co15.s$PRIORLIVE_r[co15.s$PRIORLIVE_r == "1"] <- "1_PRIORLIVE_r"
co15.s$PRIORLIVE_r[co15.s$PRIORLIVE_r == "2"] <- "2_PRIORLIVE_r"
co15.s$PRIORLIVE_r[co15.s$PRIORLIVE_r == "3"] <- "3_PRIORLIVE_r"
co15.s$PRIORLIVE_r[co15.s$PRIORLIVE_r == "4"] <- "4_PRIORLIVE_r"
co15.s$PRIORLIVE_r[co15.s$PRIORLIVE_r == "5"] <- "5_PRIORLIVE_r"
co15.s$PRIORLIVE_r[co15.s$PRIORLIVE_r == "6"] <- "6_PRIORLIVE_r"
co15.s$PRIORLIVE_r[co15.s$PRIORLIVE_r == "more than 6"] <- "more than 6_PRIORLIVE_r"
co15.s$PRIORLIVE_r <- factor(co15.s$PRIORLIVE_r,
                             levels = c( "0",
                                         "1_PRIORLIVE_r",
                                         "2_PRIORLIVE_r",
                                         "3_PRIORLIVE_r",
                                         "4_PRIORLIVE_r",
                                         "5_PRIORLIVE_r",
                                         "6_PRIORLIVE_r",
                                         "more than 6_PRIORLIVE_r"))
co15.s$PRIORLIVE_r <- relevel(co15.s$PRIORLIVE_r, ref="0")

# PRIORDEAD_r
unique(co15.s$PRIORDEAD_r)
co15.s$PRIORDEAD_r[co15.s$PRIORDEAD_r == "1"] <- "1_PRIORDEAD_r"
co15.s$PRIORDEAD_r[co15.s$PRIORDEAD_r == "2"] <- "2_PRIORDEAD_r"
co15.s$PRIORDEAD_r[co15.s$PRIORDEAD_r == "3"] <- "3_PRIORDEAD_r"
co15.s$PRIORDEAD_r[co15.s$PRIORDEAD_r == "more than 3"] <- "more than 3_PRIORDEAD_r"
co15.s$PRIORDEAD_r <- factor(co15.s$PRIORDEAD_r,
                             levels = c( "0",
                                         "1_PRIORDEAD_r",
                                         "2_PRIORDEAD_r",
                                         "3_PRIORDEAD_r",
                                         "more than 3_PRIORDEAD_r"))
co15.s$PRIORDEAD_r <- relevel(co15.s$PRIORDEAD_r, ref="0")

# PRIORTERM_r
unique(co15.s$PRIORTERM_r)
co15.s$PRIORTERM_r[co15.s$PRIORTERM_r == "1"] <- "1_PRIORTERM_r"
co15.s$PRIORTERM_r[co15.s$PRIORTERM_r == "2"] <- "2_PRIORTERM_r"
co15.s$PRIORTERM_r[co15.s$PRIORTERM_r == "more than 2"] <- "more than 2_PRIORTERM_r"
co15.s$PRIORTERM_r <- factor(co15.s$PRIORTERM_r,
                             levels = c( "0",
                                         "1_PRIORTERM_r",
                                         "2_PRIORTERM_r",
                                         "more than 2_PRIORTERM_r"))
co15.s$PRIORTERM_r <- relevel(co15.s$PRIORTERM_r, ref="0")

# PREVIS_r
unique(co15.s$PREVIS_r)
co15.s$PREVIS_r <- factor(co15.s$PREVIS_r,
                          levels = c( "0",
                                      "less than 10",
                                      "10-15",
                                      "more than 15"))
co15.s$PREVIS_r <- relevel(co15.s$PREVIS_r, ref="0")

# COMBGEST_r
unique(co15.s$COMBGEST_r)
co15.s$COMBGEST_r <- factor(co15.s$COMBGEST_r,
                            levels = c( "under 20 weeks",
                                        "20-24 weeks",
                                        "25-29 weeks",
                                        "30-34 weeks",
                                        "35-36 weeks",
                                        "37-38 weeks",
                                        "39 weeks",
                                        "40 weeks",
                                        "41 weeks",
                                        "over 41 weeks"))
co15.s$COMBGEST_r <- relevel(co15.s$COMBGEST_r, ref="39 weeks")


# AGED
sort(unique(co15.s$AGED), decreasing=FALSE)
co15.s$AGED[is.na(co15.s$AGED) & co15.s$DIED == 0] <- 364
co15.s$AGED[co15.s$AGED == 0] <- 0.2
co15.s$AGED[co15.s$AGED == 1] <- 1.2


#################################################
# Summary Statistics
#################################################
table(co15.s$AGED)
table(co15.s$DIED)
summary(co15.s)
colSums(is.na(co15.s))
sum(!complete.cases(co15.s))
sum(complete.cases(co15.s))



#################################################
# Select only variables of interest (after viewing descriptive stats)
#################################################

co15.a <- within(co15.s, rm(FEDUC_r, FRACEHISP_r, MRACEHISP_r, FAGE11_r,
                            uCA_Anen_r, uCA_Spina_r, uCA_Omph_r, uCA_Hern_r, uCA_Down_r,
                            BRTHWGT_r, COMBGEST, BMI_rC))

co15.a <- co15.a[complete.cases(co15.a), ]

# Export Data to .csv
write.csv(co15.a, file="Data/co15_a.csv", row.names=FALSE)


# Summary Statistics
###########################
nrow(co15.a)
colnames(co15.a)
table(co15.a$AGED)
table(co15.a$DIED)
summary(co15.a)
colSums(is.na(co15.a))
sum(!complete.cases(co15.a))
sum(complete.cases(co15.a))


#################################################
# Observations Casewise Deleted from the Analysis due to missing values
#################################################

co15.miss <- within(co15.s, rm(FEDUC_r, FRACEHISP_r, MRACEHISP_r, FAGE11_r,
                            uCA_Anen_r, uCA_Spina_r, uCA_Omph_r, uCA_Hern_r, uCA_Down_r,
                            BRTHWGT_r, COMBGEST, BMI_rC))

co15.miss <- co15.miss[!complete.cases(co15.miss), ]

# ensure correct data splitage
(nrow(co15.a) + nrow(co15.miss)) == nrow(co15.s)


# Export Data to .csv
write.csv(co15.miss, file="Data/co15_miss.csv", row.names=FALSE)



#################################################
# Convert Factors to Dummy Variable Coding
#################################################

X <- within(co15.a, rm(DIED, AGED, AGER5_r))
X$ind <- 1
X$id <- seq(from=1, to=nrow(co15.a))


X <- X %>% 
  pivot_wider(names_from=BFACIL_r, values_from=ind)
X <- dplyr::select(X, -c(Hospital))
X$'Home(intended)/Birth Center'[is.na(X$'Home(intended)/Birth Center')] <- 0
X$Other[is.na(X$Other)] <- 0
X$ind <- 1

X <- X %>% 
  pivot_wider(names_from=MAGER9_r, values_from=ind) 
X <- dplyr::select(X, -c(`20-24 years`))
X$`25-29 years`[is.na(X$`25-29 years`)] <- 0
X$`30-34 years`[is.na(X$`30-34 years`)] <- 0
X$`35-39 years`[is.na(X$`35-39 years`)] <- 0
X$`15-19 years`[is.na(X$`15-19 years`)] <- 0
X$`40-44 years`[is.na(X$`40-44 years`)] <- 0
X$`45-49 years`[is.na(X$`45-49 years`)] <- 0
X$`Under 15 years`[is.na(X$`Under 15 years`)] <- 0
X$`50-54 years`[is.na(X$`50-54 years`)] <- 0
X$ind <- 1

X <- X %>% 
  pivot_wider(names_from=MBSTATE_REC_r, values_from=ind)
X <- dplyr::select(X, -c(`Born outside the U.S.`))
X$`Born in the U.S.`[is.na(X$`Born in the U.S.`)] <- 0
X$ind <- 1

X <- X %>% 
  pivot_wider(names_from=MRACE6_r, values_from=ind)
X <- dplyr::select(X, -c(`White (only)`))
X[is.na(X)] <- 0 
X$ind <- 1

X <- X %>% 
  pivot_wider(names_from=DMAR_r, values_from=ind)
X <- dplyr::select(X, -c(Married))
X[is.na(X)] <- 0 
X$ind <- 1

X <- X %>% pivot_wider(names_from=MEDUC_r, values_from=ind)	
X <- dplyr::select(X, -c('High school diploma'))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=TBO_REC_r, values_from=ind)	
X <- dplyr::select(X, -c('1 total birth order'))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=ILLB_R11_r, values_from=ind)	
X <- dplyr::select(X, -c('1st birth'))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=PRECARE5_r, values_from=ind)	
X <- dplyr::select(X, -c('No prenatal care'))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=PREVIS_r, values_from=ind)	
X <- dplyr::select(X, -c('0'))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=ANY_CIG, values_from=ind)	
X <- dplyr::select(X, -c(Nonsmoker))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=PAY_r, values_from=ind)	
X <- dplyr::select(X, -c('Private Insurance/Other'))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=DPLURAL_r, values_from=ind)	
X <- dplyr::select(X, -c(Single))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=SEX_r, values_from=ind)	
X <- dplyr::select(X, -c(Female))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=BWTR4_r, values_from=ind)	
X <- dplyr::select(X, -c('2500 - 8165 grams'))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=ANOMALY, values_from=ind)	
X <- dplyr::select(X, -c(No))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=BFED_r, values_from=ind)	
X <- dplyr::select(X, -c(Yes))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=COMBGEST_r, values_from=ind)	
X <- dplyr::select(X, -c('39 weeks'))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=CIG1_R_r, values_from=ind)	
X <- dplyr::select(X, -c(Nonsmoker))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=CIG2_R_r, values_from=ind)	
X <- dplyr::select(X, -c(Nonsmoker))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=CIG3_R_r, values_from=ind)	
X <- dplyr::select(X, -c(Nonsmoker))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=uRF_Diab_r, values_from=ind)	
X <- dplyr::select(X, -c(No))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=uRF_Chype_r, values_from=ind)	
X <- dplyr::select(X, -c(No))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=uRF_Phype_r, values_from=ind)	
X <- dplyr::select(X, -c(No))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=uRf_Ehype_r, values_from=ind)	
X <- dplyr::select(X, -c(No))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=uLD_Bree_r, values_from=ind)	
X <- dplyr::select(X, -c(No))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=PRIORLIVE_r, values_from=ind)	
X <- dplyr::select(X, -c('0'))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=PRIORDEAD_r, values_from=ind)	
X <- dplyr::select(X, -c('0'))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=PRIORTERM_r, values_from=ind)	
X <- dplyr::select(X, -c('0'))	
X[is.na(X)] <- 0	
X$ind <- 1

X <- X %>% 	pivot_wider(names_from=BMI_R_r, values_from=ind)	
X <- dplyr::select(X, -c('Normal 18.5-24.9'))	
X[is.na(X)] <- 0	
X$ind <- 1





################################################################################
################################################################################
# Grouped LASSO for Logistic Regression Model
################################################################################
################################################################################

#############################
# Set up data
#############################
X <- within(X, rm(id, ind))
print(X, width=Inf)
colnames(X)

y <- co15.a$DIED

nrow(co15.a)
nrow(X)
length(y)


# Index of groupings (no penalization for DMAR, ANY_CIG, and BMI_R)
group <- c(1, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 4, 5, 5, 5, 5, 0, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 9, 9, 9, 10, 10, 10, 0, 0, 11, 12, 13, 14, 14, 15, 16, 17, 17, 17, 17, 17, 17, 17, 17, 17, 18, 18, 18, 19, 19, 19, 20, 20, 20, 21, 22, 23, 24, 25, 26, 26, 26, 26, 26, 26, 26, 27, 27, 27, 27, 28, 28, 28, 0, 0, 0, 0, 0)



############################################################################
# Perform 5-Fold Cross-Validation on Grouped LASSO to Select Optimal lambda
############################################################################
cv.lasso.log <- cv.grpreg(X=X, y=y, group=group,
                          penalty = "grLasso",
                          family = "binomial",
                          nlambda = 80,
                          alpha = 1,
                          nfolds = 5,
                          seed = 7,
                          trace = TRUE,
                          se = 'bootstrap')

summary(cv.lasso.log)

save.image("~/Academic/Case Studies in Data Analysis (STAT 634)/Infant Mortality Project/CS2_infant_mortality_study/CS2_workspace.RData")

# plot the Cross-Validation Error for each lambda
par(mfrow=c(2,2))
plot(cv.lasso.log, type='all')

par(mfrow=c(1,1))
plot(cv.lasso.log, type="cve")

# largest lambda within 1 S.E. of lambda.min appears to be any lambda that selects 5-6 factors.
# To be conservative, we select 6 factors. The Cox proportional hazards model will select out
# any factors if they do not have a low p-value


cv.lasso.log$cve[cv.lasso.log$min]  # minimum CV error
cv.lasso.log$pe          # cross-validation prediction error
cv.lasso.log$lambda.min  # lambda with minimum CV error
cv.lasso.log$min         # index of lambda with min CV error
cv.lasso.log$null.dev    # null deviance for the intercept-only model
cv.lasso.log$cvse[cv.lasso.log$min] # estimated standard error for lambda with min CV error
cv.lasso.log$lambda

# Optimal Lambda: maximum lambda within 1 S.E. of lambda.min
lambda.opt <- max(cv.lasso.log$lambda[cv.lasso.log$lambda <= 
                                        cv.lasso.log$lambda.min + cv.lasso.log$cvse[cv.lasso.log$min]])


# coefficients from model with lambda with minimum CV error
cv.lasso.log$fit$beta[, cv.lasso.log$min]  

# coefficients from model with optimal lambda
cv.lasso.log$fit$beta[, cv.lasso.log$lambda == lambda.opt]

# export coefficients from each model to .csv
write.csv(cv.lasso.log$fit$beta, file="Results/CVlogbetas.csv")





################################################################################
################################################################################
# Grouped LASSO for Cox Proportional Hazards Model
################################################################################
################################################################################

######################################################
# Perform 1-Fold Cross-Validation on Grouped LASSO
######################################################

# Split data into 70% training set and 30% test set
###################################################
# Stratify dataset on event
co15.a.A <- co15.a[co15.a$DIED == 1, ]   # infant deaths
co15.a.B <- co15.a[co15.a$DIED == 0, ]   # no infant deaths

Xdf <- as.data.frame(X)
Xdf$DIED <- co15.a$DIED
Xdf.A <- Xdf[Xdf$DIED == 1, ]  # infant deaths
Xdf.B <- Xdf[Xdf$DIED == 0, ]  # no infant deaths


# Create indices for splitting into training set and test set
set.seed(7)
strat.A <- sample(c(rep(0, 0.7 * nrow(co15.a.A)), rep(1, 0.3 * nrow(co15.a.A))), replace=FALSE)
strat.B <- sample(c(rep(0, 0.7 * nrow(co15.a.B)), rep(1, 0.3 * nrow(co15.a.B))), replace=FALSE)

# Split response into train set and test set
train_co15 <- rbind(co15.a.A[strat.A == 0, ], co15.a.B[strat.B == 0, ])
test_co15 <- rbind(co15.a.A[strat.A == 1, ], co15.a.B[strat.B == 1, ])
y.train <- Surv(train_co15$AGED, train_co15$DIED)
y.test <- Surv(test_co15$AGED, test_co15$DIED)

# Split design matrix into training set and test set
trainX_co15 <- rbind(Xdf.A[strat.A == 0, ], Xdf.B[strat.B == 0, ])
testX_co15 <- rbind(Xdf.A[strat.A == 1, ], Xdf.B[strat.B == 1, ])

#train.data <- list(x=as.matrix(trainX_co15), time=c(train_co15$AGED), status=c(train_co15$DIED))
#test.data <- list(x=as.matrix(testX_co15), time=c(test_co15$AGED), status=c(test_co15$DIED))


# fit grouped LASSO to training set
##################################
lasso.cox.train <- grpsurv(X=trainX_co15, y=y.train, index=group,
                           penalty = "grLasso",
                           nlambda = 40)

lasso.cox.train$lambda


# Predicted values from training set model with test set as input
###################################################################
lasso.cox.test <- predict(lasso.cox.train, 
                             X = as.matrix(testX_co15),
                             type = "response",
                             lambda = lasso.cox.train$lambda)

# Find the AUC for ROC curves for each lambda
testpreds  <- tibble(actual = test_co15$DIED, 
                    as.data.frame(lasso.cox.test),
                    .name_repair = "unique")
colnames(testpreds) <- c("actual", as.character(lasso.cox.train$lambda))

AUCs <- testpreds %>% 
  pivot_longer(-actual, names_to = 'lambda1', values_to = 'predicted') %>% 
  group_by(lambda1) %>% 
  summarize(auc = auc(roc(actual, predicted))[[1]],
            lambda = as.numeric(lambda1)[[1]]) %>% 
  print(n=40)

# lambda that produces the maximum AUC
lambdamin <- AUCs$lambda[which.max(AUCs$auc)]

# Lambda with minimum CV error is the minimum lambda.
# Repeat process with lambda.max*1.0e-7 as the minimum lambda in the training model


######################################################
# Perform 1-Fold Cross-Validation on Grouped LASSO
# Fine-tuned lambda (2nd iteration)
######################################################
lasso.cox.train <- grpsurv(X=trainX_co15, y=y.train, index=group,
                           penalty = "grLasso",
                           lambda.min = 1e-7,
                           nlambda = 100)

lasso.cox.train$lambda


# Predicted values from training set model with test set as input
###################################################################
lasso.cox.test <- predict(lasso.cox.train, 
                          X = as.matrix(testX_co15),
                          type = "response",
                          lambda = lasso.cox.train$lambda)

# Find the AUC for ROC curves for each lambda
testpreds  <- tibble(actual = test_co15$DIED, 
                     as.data.frame(lasso.cox.test),
                     .name_repair = "unique")
colnames(testpreds) <- c("actual", as.character(lasso.cox.train$lambda))

AUCs <- testpreds %>% 
  pivot_longer(-actual, names_to = 'lambda1', values_to = 'predicted') %>% 
  group_by(lambda1) %>% 
  summarize(auc = auc(roc(actual, predicted))[[1]],
            lambda = as.numeric(lambda1)[[1]]) %>% 
  print(n=100)

# lambda that produces the maximum AUC
AUCs$lambda[which.max(AUCs$auc)]
max(AUCs$auc)
lambdamin <- AUCs$lambda[which.max(AUCs$auc)]




############################################################################
# Perform 5-Fold Cross-Validation on Grouped LASSO to Select Optimal lambda
############################################################################

X <- X
y <- Surv(co15.a$AGED, co15.a$DIED)

nrow(co15.a)
nrow(X)
length(y)

# Index of groupings (no penalization for DMAR, ANY_CIG, and BMI_R)
group <- c(1, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 4, 5, 5, 5, 5, 0, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 9, 9, 9, 10, 10, 10, 0, 0, 11, 12, 13, 14, 14, 15, 16, 17, 17, 17, 17, 17, 17, 17, 17, 17, 18, 18, 18, 19, 19, 19, 20, 20, 20, 21, 22, 23, 24, 25, 26, 26, 26, 26, 26, 26, 26, 27, 27, 27, 27, 28, 28, 28, 0, 0, 0, 0, 0)



# 5-Fold Cross-Validation on Grouped LASSO
#####################################################
cv.lasso.cox <- cv.grpsurv(X=X, y=y, group=group,
                           penalty = "grLasso",
                           nfolds = 5,
                           seed = 7,
                           trace = TRUE,
                           se = 'quick')
summary(cv.lasso.cox)

# plot the Cross-Validation Error for each lambda
plot(cv.lasso.cox, type='all')
# largest lambda within 1 S.E. of lambda.min appears to be any lambda that selects 5-6 factors.
# To be conservative, we select 6 factors. The Cox proportional hazards model will select out
# any factors if they do not have a low p-value


cv.lasso.cox$cve[cv.lasso.cox$min]  # minimum CV error
cv.lasso.cox$lambda.min  # lambda with minimum CV error
cv.lasso.cox$min         # index of lambda with min CV error
cv.lasso.cox$null.dev    # null deviance for the intercept-only model
cv.lasso.cox$cvse[cv.lasso.cox$min] # estimated standard error for lambda with min CV error
cv.lasso.cox$lambda

# maximum lambda within 1 S.E. of lambda.min
max(cv.lasso.cox$lambda[cv.lasso.cox$lambda <= 
                          cv.lasso.cox$lambda.min + cv.lasso.cox$cvse[cv.lasso.cox$min]])
# according to grpreg documentation, computation of S.E. for cv.grpsurv(se='quick') are crude
# so this value will be ignored and the appropriate lambda will be ascertained from the plot.


# coefficients from model with lambda with minimum CV error
cv.lasso.cox$fit$beta[, cv.lasso.cox$min]  

# export coefficients from each model to .csv
write.csv(cv.lasso.cox$fit$beta, file="Results/CVcoxbetas.csv")



#########################################################
# Fit Grouped LASSO to full dataset with lambda with min Test Error on single training set
#########################################################
lasso.cox <- grpsurv(X=X, y=y, index=group,
                     penalty = "grLasso",
                     lambda = lambdamin)


#########################################################
# Fit Grouped LASSO to full dataset with lambda with min 5-fold CV Error
#########################################################
lasso.coxCV <- grpsurv(X=X, y=y, index=group,
                     penalty = "grLasso",
                     lambda = cv.lasso.cox$lambda.min)





