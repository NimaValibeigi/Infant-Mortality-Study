# Stat 634
# Case Studies 2
# Jonathan Abbamonte, Nima Valibeigi, Seyedkamyar Zojaji
# Data Visualization
# May 13, 2022

library(ggplot2)

# Forest Plot on Adjusted Odds Ratios

# AIC Model

AIC = data.frame(variable = c("Marital Status: Unmarried", "Smoking Status: Smoker", "Smoking Status: Smoker but Quit",
                              "BMI: Underweight < 18.5", "BMI: Overweight 25.0 - 29.9", "BMI: Obesity I 30.0 - 34.9",
                              "BMI: Obesity II 35.0 - 39.9", "Extreme Obesity III >= 40.0"),
                index = 1:8,
                estimate = c(0.98, 1.35, 1.15, 0.89, 1.05, 1.11, 1.21, 1.26),
                lower = c(0.94, 1.27, 1.02, 0.8, 1, 1.04, 1.12, 1.15),
                upper = c(1.04, 1.45, 1.3, 0.99, 1.11, 1.18, 1.31, 1.37))

ggplot(data = AIC, aes(y=index, x=estimate, xmin=lower, xmax=upper)) +
  geom_point() + 
  geom_errorbarh(height=.1) +
  scale_y_continuous(name = "", breaks=1:nrow(AIC), labels=AIC$variable)

# BIC Model

BIC = data.frame(variable = c("Marital Status: Unmarried", "Smoking Status: Smoker", "Smoking Status: Smoker but Quit",
                              "BMI: Underweight < 18.5", "BMI: Overweight 25.0 - 29.9", "BMI: Obesity I 30.0 - 34.9",
                              "BMI: Obesity II 35.0 - 39.9", "Extreme Obesity III >= 40.0"),
                 index = 1:8,
                 estimate = c(1.04, 1.44, 1.21, 0.9, 1.05, 1.11, 1.22, 1.26),
                 lower = c(0.99, 1.34, 1.06, 0.8, 1, 1.04, 1.12, 1.15),
                 upper = c(1.1, 1.54, 1.37, 1.01, 1.12, 1.19, 1.32, 1.37))

ggplot(data = BIC, aes(y=index, x=estimate, xmin=lower, xmax=upper)) +
  geom_point() + 
  geom_errorbarh(height=.1) +
  scale_y_continuous(name = "", breaks=1:nrow(BIC), labels=BIC$variable) + 
  

# Group Lasso Model

GL = data.frame(variable = c("Marital Status: Unmarried", "Smoking Status: Smoker", "Smoking Status: Smoker but Quit",
                              "BMI: Underweight < 18.5", "BMI: Overweight 25.0 - 29.9", "BMI: Obesity I 30.0 - 34.9",
                              "BMI: Obesity II 35.0 - 39.9", "Extreme Obesity III >= 40.0"),
                 index = 1:8,
                 estimate = c(1.13, 1.48, 1.21, 0.94, 1.04, 1.1, 1.19, 1.21),
                 lower = c(1.08, 1.37, 1.05, 0.82, 0.98, 1.02, 1.09, 1.1),
                 upper = c(1.19, 1.59, 1.39, 1.06, 1.11, 1.18, 1.3, 1.34))

ggplot(data = GL, aes(y=index, x=estimate, xmin=lower, xmax=upper)) +
  geom_point() + 
  geom_errorbarh(height=.1) +
  scale_y_continuous(name = "", breaks=1:nrow(GL), labels=GL$variable)

GL_all = data.frame(variable = c("Marital Status: Unmarried", "Smoking Status: Smoker", "Smoking Status: Smoker but Quit",
                                 "BMI: Underweight < 18.5", "BMI: Overweight 25.0 - 29.9", "BMI: Obesity I 30.0 - 34.9",
                                 "BMI: Obesity II 35.0 - 39.9", "Extreme Obesity III >= 40.0", "Infant Birth Weight: 227 - 1499 grams",
                                 "Infant Birth Weight: 1500 - 2499 grams", "Gestation Period: Under 20 weeks", "Gestation Period: 20-24 weeks",
                                 "Gestation Period: 25-29 weeks", "Gestation Period: 30-34 weeks", "Gestation Period: 35-36 weeks",
                                 "Gestation Period: 37-38 weeks", "Gestation Period: 39 weeks", "Gestation Period: 41 weeks", 
                                 "Gestation Period: Over 41 weeks", "APGAR 5-min score", "Fetal Anomaly: Yes", "Breast Fed: No",
                                 "Breech Delivery: Yes", "Number of Prenatal Visits: 10 or more"),
                index = 1:24,
                estimate = c(1.13, 1.48, 1.21, 0.94, 1.04, 1.1, 1.19, 1.21, 6.87, 2.96, 10.36, 8.21, 2.2, 1.4, 1.4, 1.32,
                             1.14, 1.04, 1.24, 0.63, 15.68, 2.38, 1.14, 0.73),
                lower = c(1.08, 1.37, 1.05, 0.82, 0.98, 1.02, 1.09, 1.1, 6.05, 2.74, 7.6, 6.95, 1.88, 1.24, 1.25, 1.2, 1.03,
                          0.9, 1.07, 0.62, 13.41, 2.26, 1.07, 0.7),
                upper = c(1.19, 1.59, 1.39, 1.06, 1.11, 1.18, 1.3, 1.34, 7.79, 3.2, 14.28, 9.71, 2.57, 1.59, 1.58, 1.46, 1.26,
                          1.19, 1.43, 0.63, 18.26, 2.51, 1.22, 0.77))

ggplot(data = GL_all, aes(y=index, x=estimate, xmin=lower, xmax=upper)) +
  geom_point() + 
  geom_errorbarh(height=.1) +
  scale_y_continuous(name = "", breaks=1:nrow(GL_all), labels=GL_all$variable)

# Forest Plot on Marital Status Hazards Ratio

HR = data.frame(variable = c("Marital Status: Unmarried (if t < 2 days)", "Marital Status: Unmarried (if 1 < t < 3 days)",
                             "Marital Status: Unmarried (if 2 < t < 20 days)", "Marital Status: Unmarried (if 20 < t < 105 days)",
                             "Marital Status: Unmarried (if 20 < t < 105 days) * log(t)", "Marital Status: Unmarried (if 104 < t < 362 days)",
                             "Marital Status: Unmarried (if 104 < t < 362 days) * log(t)", "Marital Status: Unmarried (if t > 362 days)",
                             "Smoking Status: Smoker", "Smoking Status: Smoker but Quit", "BMI: Underweight < 18.5", "BMI: Overweight 25.0 - 29.9",
                             "BMI: Obesity I 30.0 - 34.9", "BMI: Obesity II 35.0 - 39.9", "BMI: Extreme Obesity III >= 40.0"),
                index = 1:15, 
                estimate = c(1.01, 1.44, 1.08, 0.31, 1.46, 0.1, 1.82, 0.35, 1.29, 1.14, 1.09, 1.02, 1.02, 1.08, 1), 
                lower = c(0.97, 1.14, 1.04, 0.28, 1.41, 0.08, 1.76, 0.29, 1.22, 1.04, 1, 0.98, 0.97, 1.01, 0.94),
                upper = c(1.05, 1.82, 1.12, 0.35, 1.5, 0.12, 1.87, 0.42, 1.36, 1.25, 1.19, 1.06, 1.07, 1.14, 1.07))

ggplot(data = HR, aes(y=index, x=estimate, xmin=lower, xmax=upper)) +
  geom_point() + 
  geom_errorbarh(height=.1) +
  scale_y_continuous(name = "", breaks=1:nrow(HR), labels=HR$variable)                
                             
# KM Plot

library(survival)
co15.d = read.csv("co15_d.csv", header = TRUE)
model = survfit(Surv(AGED, DIED) ~ 1, data = co15.d)
autoplot(model)





