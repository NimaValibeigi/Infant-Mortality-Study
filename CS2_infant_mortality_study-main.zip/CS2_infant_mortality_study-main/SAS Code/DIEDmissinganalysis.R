# Reading in Missing and Non-Missing Data #
miss <- read_csv("co15_miss.csv")
nonmiss <-read_csv("co15_a.csv")

# 2-sided T-test (missing versus non-missing data) # DIED #

t.test(miss$DIED, nonmiss$DIED, alternative = "two.sided")

#proportions variable in missing data # DIED #
prop.table(table(miss$DIED))
prop.table(table(nonmiss$DIED))

# Visualized Barplot#
par(mfrow=c(1,2))
barplot(main = "Non Missing", xlab = "DIED", ylab = "Proportion", prop.table(table(nonmiss$DIED)))
barplot(main = "Missing", xlab = "DIED", ylab = "Proportion", prop.table(table(miss$DIED)))