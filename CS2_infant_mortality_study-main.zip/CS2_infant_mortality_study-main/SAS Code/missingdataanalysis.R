library(imputeTS)
library(rnoaa)
library(dplyr)
library(readr)
library(funModeling) 
library(tidyverse) 
library(Hmisc)
library(readxl)
library(forecast)
################################################################################
#
#
#
#
############################## Patterns of Missingnes ##################################

miss <- read_csv("co15_miss.csv")
nonmiss <-read_csv("co15_a.csv")
all <-read_csv("LINK15_recode.csv")

install.packages("naniar")
library(naniar)
install.packages("finalfit")
library(finalfit)
install.packages("dplyr")
library(dplyr)

#missing data tabulations#
miss_var_table(miss)
miss_var_table(nonmiss)
miss_var_table(all)

#Spans of Missing Data (BMI)#
miss_var_span(miss, var = BMI_R_r, span_every = 95667)
miss_var_span(nonmiss, var = BMI_R_r, span_every = 24555)
miss_var_span(all, var = BMI_R_r, span_every = 150000)

#Missing Value by Group (BMI)#
all %>%
  group_by(BMI_R_r) %>%
  miss_var_summary(order = TRUE)

#Summary of Missing Values (Best One)#
all %>%
  ff_glimpse()

miss %>%
  ff_glimpse()

nonmiss %>%
  ff_glimpse()
#glimpes per var#
#               #
#               #
#               #
#  Proper form  #
install.packages("C50")
library(C50)
library(dplyr)


BMII = all$BMI
BMII
AGER = all$AGER5_r
AGER
CIG = all$CIG_0
DMAR = all$DMAR
all2 <- all %>%
  dplyr::mutate(BMIcat=factor(BMII, levels = c(0,100))) %>% dplyr::collect()


all2 %>%
  ff_glimpse(explanatory = all2$BMIcat)

# gg_plot missing dataset (all)# 
install.packages("ggplot2")
install.packages("tidyverse")
library(ggplot2)


ggplot() + geom_point(all, mapping = aes(BMII,AGER))

# Frequency of NA per sig var #
ILLB_nonmiss = nonmiss$ILLB_R11_r
install.packages("questionr")
library(questionr)
freq.na(all, "BMII", "AGER")
freq.na(all, "CIG", "AGER")
freq.na(nonmiss, "ILLB_nonmiss")
miss$ILLB_R11_r


# 2-sided T-test (missing versus non-missing data) AGER5#

  t.test(miss$DIED, nonmiss$DIED, alternative = "two.sided")
  
  colnames(miss)
  
#proportions variable in missing data #
  prop.table(table(miss$DMAR_r))
  prop.table(table(miss$BFACIL_r))
  prop.table(table(miss$MAGER9_r))
  prop.table(table(miss$MBSTATE_REC_r))
  prop.table(table(miss$MRACE6_r))
  prop.table(table(miss$DMAR_r))
  prop.table(table(miss$MEDUC_r))
  prop.table(table(miss$TBO_REC_r))
  prop.table(table(miss$ILLB_R11_r))
  prop.table(table(miss$PRECARE5_r))
  prop.table(table(miss$PREVIS_r))
  prop.table(table(miss$BMI_R_r))
  prop.table(table(miss$PAY_r))
  prop.table(table(miss$APGAR5_r))
  prop.table(table(miss$DPLURAL_r))
  prop.table(table(miss$SEX_r))
  prop.table(table(miss$BWTR4_r))
  prop.table(table(miss$ANOMALY))
  prop.table(table(miss$BFED_r))
  prop.table(table(miss$COMBGEST_r))
  prop.table(table(miss$ANY_CIG))
  prop.table(table(miss$CIG1_R_r))
  prop.table(table(miss$CIG2_R_r))
  prop.table(table(miss$CIG3_R_r))
  prop.table(table(miss$uRF_Diab_r))
  prop.table(table(miss$uRF_Chype_r))
  prop.table(table(miss$uRF_Phype_r))
  prop.table(table(miss$uRf_Ehype_r))
  prop.table(table(miss$uLD_Bree_r))
  prop.table(table(miss$PRIORDEAD_r))
  prop.table(table(miss$PRIORTERM_r))
  prop.table(table(miss$PRIORLIVE_r))
  prop.table(table(miss$AGER5_r))
  prop.table(table(miss$DIED))
  
  
#proportions variable in non- missing data #
  prop.table(table(nonmiss$DMAR_r))
  prop.table(table(nonmiss$BFACIL_r))
  prop.table(table(nonmiss$MAGER9_r))
  prop.table(table(nonmiss$MBSTATE_REC_r))
  prop.table(table(nonmiss$MRACE6_r))
  prop.table(table(nonmiss$DMAR_r))
  prop.table(table(nonmiss$MEDUC_r))
  prop.table(table(nonmiss$TBO_REC_r))
  prop.table(table(nonmiss$ILLB_R11_r))
  prop.table(table(nonmiss$PRECARE5_r))
  prop.table(table(nonmiss$PREVIS_r))
  prop.table(table(nonmiss$BMI_R_r))
  prop.table(table(nonmiss$PAY_r))
  prop.table(table(nonmiss$APGAR5_r))
  prop.table(table(nonmiss$DPLURAL_r))
  prop.table(table(nonmiss$SEX_r))
  prop.table(table(nonmiss$BWTR4_r))
  prop.table(table(nonmiss$ANOMALY))
  prop.table(table(nonmiss$BFED_r))
  prop.table(table(nonmiss$COMBGEST_r))
  prop.table(table(nonmiss$ANY_CIG))
  prop.table(table(nonmiss$CIG1_R_r))
  prop.table(table(nonmiss$CIG2_R_r))
  prop.table(table(nonmiss$CIG3_R_r))
  prop.table(table(nonmiss$uRF_Diab_r))
  prop.table(table(nonmiss$uRF_Chype_r))
  prop.table(table(nonmiss$uRF_Phype_r))
  prop.table(table(nonmiss$uRf_Ehype_r))
  prop.table(table(nonmiss$uLD_Bree_r))
  prop.table(table(nonmiss$PRIORDEAD_r))
  prop.table(table(nonmiss$PRIORTERM_r))
  prop.table(table(nonmiss$PRIORLIVE_r))
  prop.table(table(nonmiss$AGER5_r))
  prop.table(table(nonmiss$DIED))
 
  
  # Visualized Barplot#
 par(mfrow=c(1,2))
 
 
 
 #DIED#
 barplot(main = "Non Missing", xlab = "DIED", ylab = "Proportion", prop.table(table(nonmiss$DIED)))
 barplot(main = "Missing", xlab = "DIED", ylab = "Proportion", prop.table(table(miss$DIED)))
 
 #OR comparison DIED ()#
 OR_DMAR_nonmiss <- glm(DIED ~ DMAR_r, data=nonmiss, family=binomial(link='logit'))
 exp(cbind(OR=coef(OR_DMAR), confint(OR_DMAR)))
 OR_DMAR_nonmiss
 
 OR_DMAR_miss <- glm(DIED ~ DMAR_r, data=miss, family=binomial(link='logit'))
 exp(cbind(OR=coef(OR_DMAR), confint(OR_DMAR)))
 OR_DMAR_miss
 
