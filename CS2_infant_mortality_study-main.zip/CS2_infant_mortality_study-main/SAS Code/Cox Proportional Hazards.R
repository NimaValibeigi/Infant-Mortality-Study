#                       STAT 634 - CASE STUDY 2

################################################################################
#                     Cox Proportional Hazards Model
################################################################################
# coded by: Jonathan Abbamonte

# load libraries
library(survival)
library(survminer)
library(KMsurv)
library(survMisc)
library(MASS)
library(haven)
library(tidyverse)
library(grplasso)
library(SGL)
library(grpreg)
library(scales)
library(pROC)
select <- dplyr::select


#################################################
# Load Dataset
#################################################
co15 <- read_sas("Data/co15.sas7bdat")

# all variables in dataset
colnames(co15)

# Subset dataset to recoded variables to be fitted to the model
co15.s <- co15 %>% 
  dplyr::select(BFACIL_r,
                MAGER9_r,
                MBSTATE_REC_r,
                MRACE6_r,
                MRACEHISP_r,
                DMAR_r,
                MEDUC_r,
                FAGE11_r,
                FRACEHISP_r,
                FEDUC_r,
                TBO_REC_r,
                ILLB_R11_r,
                PRECARE5_r,
                PREVIS_r,
                BMI_rC,
                BMI_R_r,
                PAY_r,
                APGAR5_r,
                DPLURAL_r,
                SEX_r,
                BWTR4_r,
                ANOMALY,
                BFED_r,
                COMBGEST_r,
                ANY_CIG,
                CIG1_R_r,
                CIG2_R_r,
                CIG3_R_r,
                uRF_Diab_r,
                uRF_Chype_r,
                uRF_Phype_r,
                uRf_Ehype_r,
                uLD_Bree_r,
                PRIORDEAD_r,
                PRIORTERM_r,
                PRIORLIVE_r,
                uCA_Anen_r,
                uCA_Spina_r,
                uCA_Omph_r,
                uCA_Hern_r,
                uCA_Down_r,
                BRTHWGT_r,
                COMBGEST,
                
                AGER5_r,
                AGED,
                DIED
  )

# Export CO15.s to CSV
write.csv(co15.s, file="Data/co15_r.csv", row.names=FALSE)

# Import CSV for leaner dataset w/o attrib names
co15.b <- read.csv("Data/co15_r.csv", header=TRUE)
#co15.b <- co15.l



#################################################
# Recoding
#################################################
# convert categorical variables to factors
# BFACIL_r
unique(co15.b$BFACIL_r)
co15.b$BFACIL_r <- factor(co15.b$BFACIL_r,
                          levels = c( "Hospital",
                                      "Home(intended)/Birth Center",
                                      "Other"))
# MAGER9_r
unique(co15.b$MAGER9_r)
co15.b$MAGER9_r <- factor(co15.b$MAGER9_r,
                          levels = c("Under 15 years",
                                     "15-19 years",
                                     "20-24 years",
                                     "25-29 years",
                                     "30-34 years",
                                     "35-39 years",
                                     "40-44 years",
                                     "45-49 years",
                                     "50-54 years"))
co15.b$MAGER9_r <- relevel(co15.b$MAGER9_r, ref="20-24 years")

# MBSTATE_REC_r
unique(co15.b$MBSTATE_REC_r)
co15.b$MBSTATE_REC_r <- factor(co15.b$MBSTATE_REC_r,
                               levels = c("Born in the U.S.",
                                          "Born outside the U.S."))
co15.b$MBSTATE_REC_r <- relevel(co15.b$MBSTATE_REC_r, ref="Born in the U.S.")

# MRACE6_r
unique(co15.b$MRACE6_r)
co15.b$MRACE6_r <- factor(co15.b$MRACE6_r,
                             levels = c(  "White (only)",
                                          "Black (only)",
                                          "AIAN/NHOPI",
                                          "Asian (only)",
                                          "More than one race"))
co15.b$MRACE6_r <- relevel(co15.b$MRACE6_r, ref="White (only)")

# MRACEHISP_r
unique(co15.b$MRACEHISP_r)
co15.b$MRACEHISP_r <- factor(co15.b$MRACEHISP_r,
                               levels = c( "White",
                                           "Black",
                                           "AIAN/NHOPI",
                                           "Asian",
                                           "Hispanic",
                                           "more than one race"))
co15.b$MRACEHISP_r <- relevel(co15.b$MRACEHISP_r, ref="White")

# DMAR_r
unique(co15.b$DMAR_r)
co15.b$DMAR_r <- factor(co15.b$DMAR_r,
                         levels = c("Married", "Unmarried"))
co15.b$DMAR_r <- relevel(co15.b$DMAR_r, ref="Married")

# MEDUC_r
unique(co15.b$MEDUC_r)
co15.b$MEDUC_r <- factor(co15.b$MEDUC_r,
                         levels = c( "8th grade or less",
                                     "9th-12th grade, no diploma",
                                     "High school diploma",
                                     "Some college, no degree",
                                     "Associate degree",
                                     "Bachelor's degree",
                                     "Master's degree",
                                     "Doctorate/Professional"))
co15.b$MEDUC_r <- relevel(co15.b$MEDUC_r, ref="High school diploma")

# FAGE11_r
unique(co15.b$FAGE11_r)
co15.b$FAGE11_r <- factor(co15.b$FAGE11_r, 
                          levels = c("Under 15 yea",
                                     "15-19 years",
                                     "20-24 years",
                                     "25-29 years",
                                     "30-34 years",
                                     "35-39 years",
                                     "40-44 years",
                                     "45-49 years",
                                     "50-54 years"))
co15.b$FAGE11_r <- relevel(co15.b$FAGE11_r, ref="20-24 years")

# FRACEHISP_r
unique(co15.b$FRACEHISP_r)
co15.b$FRACEHISP_r <- factor(co15.b$FRACEHISP_r,
                             levels = c( "White",
                                         "Black",
                                         "AIAN/NHOPI",
                                         "Asian",
                                         "Hispanic",
                                         "more than one race"))
co15.b$FRACEHISP_r <- relevel(co15.b$FRACEHISP_r, ref="White")

# FEDUC_r
unique(co15.b$FEDUC_r)
co15.b$FEDUC_r <- factor(co15.b$FEDUC_r,
                         levels = c( "8th grade or less",
                                     "9th-12th grade, no diploma",
                                     "High school diploma",
                                     "Some college, no degree",
                                     "Associate degree",
                                     "Bachelor's degree",
                                     "Master's degree",
                                     "Doctorate/Professional"))
co15.b$FEDUC_r <- relevel(co15.b$FEDUC_r, ref="High school diploma")

# ILLB_R11_r
unique(co15.b$ILLB_R11_r)
co15.b$ILLB_R11_r <- factor(co15.b$ILLB_R11_r,
                         levels = c( "1st birth",
                                     "0-3 mo.",
                                     "4-11 mo.",
                                     "12-17 mo.",
                                     "18-23 mo.",
                                     "24-35 mo.",
                                     "over 36 mo."))
co15.b$ILLB_R11_r <- relevel(co15.b$ILLB_R11_r, ref="1st birth")

# PRECARE5_r
unique(co15.b$PRECARE5_r)
co15.b$PRECARE5_r <- factor(co15.b$PRECARE5_r,
                            levels = c( "1st to 3rd month",
                                        "4th to 6th month",
                                        "7th to final month",
                                        "No prenatal care"))
co15.b$PRECARE5_r <- relevel(co15.b$PRECARE5_r, ref="No prenatal care")

# CIG1_R_r
unique(co15.b$CIG1_R_r)
co15.b$CIG1_R_r <- factor(co15.b$CIG1_R_r,
                            levels = c( "Nonsmoker",
                                        "1-5 cigarettes",
                                        "6-10 cigarettes",
                                        "more than 10 cigarettes"))
co15.b$CIG1_R_r <- relevel(co15.b$CIG1_R_r, ref="Nonsmoker")

# CIG2_R_r
unique(co15.b$CIG2_R_r)
co15.b$CIG2_R_r <- factor(co15.b$CIG2_R_r,
                        levels = c( "Nonsmoker",
                                    "1-5 cigarettes",
                                    "6-10 cigarettes",
                                    "more than 10 cigarettes"))
co15.b$CIG2_R_r <- relevel(co15.b$CIG2_R_r, ref="Nonsmoker")

# CIG3_R_r
unique(co15.b$CIG3_R_r)
co15.b$CIG3_R_r <- factor(co15.b$CIG3_R_r,
                        levels = c( "Nonsmoker",
                                    "1-5 cigarettes",
                                    "6-10 cigarettes",
                                    "more than 10 cigarettes"))
co15.b$CIG3_R_r <- relevel(co15.b$CIG3_R_r, ref="Nonsmoker")

# ANY_CIG
unique(co15.b$ANY_CIG)
co15.b$ANY_CIG <- factor(co15.b$ANY_CIG,
                        levels = c( "Nonsmoker",
                                    "Smoker",
                                    "Smoker, quit"))
co15.b$ANY_CIG <- relevel(co15.b$ANY_CIG, ref="Nonsmoker")

# BMI_R_r
unique(co15.b$BMI_R_r)
co15.b$BMI_R_r <- factor(co15.b$BMI_R_r,
                         levels = c( "Underweight <18.5",
                                     "Normal 18.5-24.9",
                                     "Overweight 25.0-29.9",
                                     "Obesity I 35.0-39.9",
                                     "Obesity II 35.0-39.9",
                                     "Extreme Obesity III >=40.0"))
co15.b$BMI_R_r <- relevel(co15.b$BMI_R_r, ref="Normal 18.5-24.9")

# uRF_Diab_r
unique(co15.b$uRF_Diab_r)
co15.b$uRF_Diab_r <- factor(co15.b$uRF_Diab_r,
                         levels = c("Yes", "No"))
co15.b$uRF_Diab_r <- relevel(co15.b$uRF_Diab_r, ref="No")

# uRF_Chype_r
unique(co15.b$uRF_Chype_r)
co15.b$uRF_Chype_r <- factor(co15.b$uRF_Chype_r,
                          levels = c("Yes", "No"))
co15.b$uRF_Chype_r <- relevel(co15.b$uRF_Chype_r, ref="No")

# uRF_Phype_r
unique(co15.b$uRF_Phype_r)
co15.b$uRF_Phype_r <- factor(co15.b$uRF_Phype_r,
                          levels = c("Yes", "No"))
co15.b$uRF_Phype_r <- relevel(co15.b$uRF_Phype_r, ref="No")

# uRf_Ehype_r
unique(co15.b$uRf_Ehype_r)
co15.b$uRf_Ehype_r <- factor(co15.b$uRf_Ehype_r,
                          levels = c("Yes", "No"))
co15.b$uRf_Ehype_r <- relevel(co15.b$uRf_Ehype_r, ref="No")

# uLD_Bree_r
unique(co15.b$uLD_Bree_r)
co15.b$uLD_Bree_r <- factor(co15.b$uLD_Bree_r,
                          levels = c("Yes", "No"))
co15.b$uLD_Bree_r <- relevel(co15.b$uLD_Bree_r, ref="No")

# PAY_r
unique(co15.b$PAY_r)
co15.b$PAY_r <- factor(co15.b$PAY_r,
                          levels = c("Private Insurance/Other", 
                                     "Medicaid/IHS"))
co15.b$PAY_r <- relevel(co15.b$PAY_r, ref="Private Insurance/Other")

# DPLURAL_r
unique(co15.b$DPLURAL_r)
co15.b$DPLURAL_r <- factor(co15.b$DPLURAL_r,
                         levels = c( "Single",
                                     "Multiple"))
co15.b$DPLURAL_r <- relevel(co15.b$DPLURAL_r, ref="Single")

# SEX_r
unique(co15.b$SEX_r)
co15.b$SEX_r <- factor(co15.b$SEX_r,
                         levels = c( "Female",
                                     "Male"))
co15.b$SEX_r <- relevel(co15.b$SEX_r, ref="Female")

# BWTR4_r
unique(co15.b$BWTR4_r)
co15.b$BWTR4_r <- factor(co15.b$BWTR4_r,
                         levels = c( "2500 - 8165 grams",
                                     "1500 - 2499 grams",
                                     "227 - 1499 grams"))
co15.b$BWTR4_r <- relevel(co15.b$BWTR4_r, ref="2500 - 8165 grams")

# BFED_r
unique(co15.b$BFED_r)
co15.b$BFED_r <- factor(co15.b$BFED_r,
                         levels = c( "Yes",
                                     "No"))
co15.b$BFED_r <- relevel(co15.b$BFED_r, ref="Yes")

# TBO_REC_r
unique(co15.b$TBO_REC_r)
co15.b$TBO_REC_r <- factor(co15.b$TBO_REC_r,
                         levels = c( "1 total birth order",
                                     "2 total birth order",
                                     "3 total birth order",
                                     "4 total birth order",
                                     "5 total birth order",
                                     "6 total birth order",
                                     "7 or more total births"))
co15.b$TBO_REC_r <- relevel(co15.b$TBO_REC_r, ref="1 total birth order")

# uCA_Anen_r
unique(co15.b$uCA_Anen_r)
co15.b$uCA_Anen_r <- factor(co15.b$uCA_Anen_r,
                         levels = c("No", "Yes"))
co15.b$uCA_Anen_r <- relevel(co15.b$uCA_Anen_r, ref="No")

# uCA_Spina_r
unique(co15.b$uCA_Spina_r)
co15.b$uCA_Spina_r <- factor(co15.b$uCA_Spina_r,
                            levels = c("No", "Yes"))
co15.b$uCA_Spina_r <- relevel(co15.b$uCA_Spina_r, ref="No")

# uCA_Omph_r
unique(co15.b$uCA_Omph_r)
co15.b$uCA_Omph_r <- factor(co15.b$uCA_Omph_r,
                            levels = c("No", "Yes"))
co15.b$uCA_Omph_r <- relevel(co15.b$uCA_Omph_r, ref="No")

# uCA_Hern_r
unique(co15.b$uCA_Hern_r)
co15.b$uCA_Hern_r <- factor(co15.b$uCA_Hern_r,
                            levels = c("No", "Yes"))
co15.b$uCA_Hern_r <- relevel(co15.b$uCA_Hern_r, ref="No")

# uCA_Down_r
unique(co15.b$uCA_Down_r)
co15.b$uCA_Down_r <- factor(co15.b$uCA_Down_r,
                            levels = c("No", "Yes"))
co15.b$uCA_Down_r <- relevel(co15.b$uCA_Down_r, ref="No")

# ANOMALY
unique(co15.b$ANOMALY)
co15.b$ANOMALY <- factor(co15.b$ANOMALY,
                            levels = c("No", "Yes"))
co15.b$ANOMALY <- relevel(co15.b$ANOMALY, ref="No")

# PRIORLIVE_r
unique(co15.b$PRIORLIVE_r)
co15.b$PRIORLIVE_r <- factor(co15.b$PRIORLIVE_r,
                         levels = c( "0",
                                     "1",
                                     "2",
                                     "3",
                                     "4",
                                     "5",
                                     "6",
                                     "more than 6"))
co15.b$PRIORLIVE_r <- relevel(co15.b$PRIORLIVE_r, ref="0")

# PRIORDEAD_r
unique(co15.b$PRIORDEAD_r)
co15.b$PRIORDEAD_r <- factor(co15.b$PRIORDEAD_r,
                             levels = c( "0",
                                         "1",
                                         "2",
                                         "3",
                                         "more than 3"))
co15.b$PRIORDEAD_r <- relevel(co15.b$PRIORDEAD_r, ref="0")

# PRIORTERM_r
unique(co15.b$PRIORTERM_r)
co15.b$PRIORTERM_r <- factor(co15.b$PRIORTERM_r,
                             levels = c( "0",
                                         "1",
                                         "2",
                                         "more than 2"))
co15.b$PRIORTERM_r <- relevel(co15.b$PRIORTERM_r, ref="0")

# PREVIS_r
unique(co15.b$PREVIS_r)
co15.b$PREVIS_r <- factor(co15.b$PREVIS_r,
                         levels = c( "0",
                                     "less than 10",
                                     "10-15",
                                     "more than 15"))
co15.b$PREVIS_r <- relevel(co15.b$PREVIS_r, ref="0")

# COMBGEST_r
unique(co15.b$COMBGEST_r)
co15.b$COMBGEST_r <- factor(co15.b$COMBGEST_r,
                         levels = c( "under 20 weeks",
                                     "20-24 weeks",
                                     "25-29 weeks",
                                     "30-34 weeks",
                                     "35-36 weeks",
                                     "37-38 weeks",
                                     "39 weeks",
                                     "40 weeks",
                                     "41 weeks",
                                     "over 41 weeks"))
co15.b$COMBGEST_r <- relevel(co15.b$COMBGEST_r, ref="39 weeks")


# AGED
sort(unique(co15.b$AGED), decreasing=FALSE)
co15.b$AGED[is.na(co15.b$AGED) & co15.b$DIED == 0] <- 364
#for (k in 1:nrow(co15.s)) {
# ifelse(!is.na(co15.s$AGED[k]), co15.s$AGED[k] <- co15.s$AGED[k] + 1, w<-2)
#}

co15.b$AGED[co15.b$AGED == 0] <- 1.2
co15.b$AGED[co15.b$AGED == 1] <- 1.8


table(co15.b$AGED)
table(co15.b$AGER5_r)



#################################################
# Dataset for Cox PH model
#################################################


co15.c <- within(co15.b, rm(FEDUC_r, FRACEHISP_r, MRACEHISP_r, FAGE11_r,
                            uCA_Anen_r, uCA_Spina_r, uCA_Omph_r, uCA_Hern_r, uCA_Down_r,
                            BRTHWGT_r, COMBGEST, BMI_rC))
co15.c <- co15.c[complete.cases(co15.c),]


#################################################
# Summary Statistics
#################################################
table(co15.b$AGED)
table(co15.b$DIED)
summary(co15.b)
colSums(is.na(co15.b))
nrow(co15.b)
nrow(co15)
sum(!complete.cases(co15.b))
sum(complete.cases(co15.b))

nrow(co15.c)
ncol(co15.c)
colnames(co15.c)
colSums(is.na(co15.c))
sum(complete.cases(co15.c))
sum(!complete.cases(co15.c))
summary(co15.c)




#################################################
# Cox Proportional Hazards Model
#################################################

# BFACIL_r + SEX_r + uRF_Phype_r
memory.limit(size = 16926400)

# fit cox proportional hazards model
cph1 <- coxph(Surv(AGED, DIED) ~ 
                  APGAR5_r +
                  DMAR_r +
                  PREVIS_r +
                  ANY_CIG +
                  BWTR4_r +
                  ANOMALY +
                  BFED_r +
                  COMBGEST_r +
                  BMI_R_r +
                  BFACIL_r +
                  SEX_r +
                  uRF_Phype_r,
              data=co15.c,
              ties='efron',
              na.action = na.omit, 
              x = TRUE, y = TRUE)

summary(cph1)


# Test proportional hazards assumption
assess.cph1id <- cox.zph(cph1, transform="identity", terms=TRUE, global=TRUE)
assess.cph1km <- cox.zph(cph1, transform="km", terms=TRUE, global=TRUE)
assess.cph1log <- cox.zph(cph1, transform="log", terms=TRUE, global=TRUE)

assess.cph1log$table

par(mfrow=c(3,3))
plot(assess.cph1log, col="red")

# APGAR5_r
m1a <- coxph(Surv(AGED, DIED) ~ APGAR5_r + tt(APGAR5_r),
            data = co15.c, ties = 'efron',
            tt = function(x,t,...) x*log(t))
m1b <- coxph(Surv(AGED, DIED) ~ APGAR5_r,
            data = co15.c, ties = 'efron',
            tt = function(x,t,...) x*log(t))
summary(m1)
anova(m1a, m1b)
( lik1 <- -2*(logLik(m1b) - logLik(m1a)) )
pchisq(lik1, df=1)

# DMAR_r
m2a <- coxph(Surv(AGED, DIED) ~ DMAR_r + tt(DMAR_r),
             data = co15.c, ties = 'efron',
             tt = function(x,t,...) x*t)
m2b <- coxph(Surv(AGED, DIED) ~ DMAR_r,
             data = co15.c, ties = 'efron',
             tt = function(x,t,...) x*log(t))
summary()
anova(m2a, m2b)

# PREVIS_r
m3a <- coxph(Surv(AGED, DIED) ~ PREVIS_r + tt(PREVIS_r),
             data = co15.c, ties = 'efron',
             tt = function(x,t,...) x*log(t))
m3b <- coxph(Surv(AGED, DIED) ~ PREVIS_r,
             data = co15.c, ties = 'efron',
             tt = function(x,t,...) x*log(t))
summary()
anova(m3a, m3b)

# ANY_CIG
m7a <- coxph(Surv(AGED, DIED) ~ ANY_CIG + tt(ANY_CIG),
             data = co15.c, ties = 'efron',
             tt = function(x,t,...) x*log(t))
m7b <- coxph(Surv(AGED, DIED) ~ ANY_CIG,
             data = co15.c, ties = 'efron',
             tt = function(x,t,...) x*log(t))
summary()
anova(m7a, m7b)

# BWTR4_r
m8a <- coxph(Surv(AGED, DIED) ~ BWTR4_r + tt(BWTR4_r),
             data = co15.c, ties = 'efron',
             tt = function(x,t,...) x*log(t))
m8b <- coxph(Surv(AGED, DIED) ~ BWTR4_r,
             data = co15.c, ties = 'efron',
             tt = function(x,t,...) x*log(t))
summary()
anova(m8a, m8b)

# BFED_r
m4a <- coxph(Surv(AGED, DIED) ~ BFED_r + tt(BFED_r),
             data = co15.c, ties = 'efron',
             tt = function(x,t,...) x*log(t))
m4b <- coxph(Surv(AGED, DIED) ~ BFED_r,
             data = co15.c, ties = 'efron',
             tt = function(x,t,...) x*log(t))
summary()
anova(m4a, m4b)

# COMBGEST_r
m5a <- coxph(Surv(AGED, DIED) ~ COMBGEST_r + tt(COMBGEST_r),
             data = co15.c, ties = 'efron',
             tt = function(x,t,...) x*log(t))
m5b <- coxph(Surv(AGED, DIED) ~ COMBGEST_r,
             data = co15.c, ties = 'efron',
             tt = function(x,t,...) x*log(t))
summary()
anova(m5a, m5b)

# SEX_r
m6a <- coxph(Surv(AGED, DIED) ~ SEX_r + tt(SEX_r),
             data = co15.c, ties = 'efron',
             tt = function(x,t,...) x*log(t))
m6b <- coxph(Surv(AGED, DIED) ~ SEX_r,
             data = co15.c, ties = 'efron',
             tt = function(x,t,...) x*log(t))
summary()
anova(m6a, m6b)

# uRF_Phype_r
m9a <- coxph(Surv(AGED, DIED) ~ uRF_Phype_r + tt(uRF_Phype_r),
             data = co15.c, ties = 'efron',
             tt = function(x,t,...) x*log(t))
m9b <- coxph(Surv(AGED, DIED) ~ uRF_Phype_r,
             data = co15.c, ties = 'efron',
             tt = function(x,t,...) x*log(t))
summary()
anova(m9a, m9b)






# fit cox proportional hazards model
cph2 <- coxph(Surv(AGED, DIED) ~ 
                APGAR5_r + tt(APGAR5_r) +
                DMAR_r + tt(DMAR_r) +
                PREVIS_r + tt(PREVIS_r) +
                ANY_CIG +
                BWTR4_r +
                ANOMALY +
                BFED_r + tt(BFED_r) +
                COMBGEST_r + tt(COMBGEST_r) +
                BMI_R_r +
                BFACIL_r +
                SEX_r + tt(SEX_r) +
                uRF_Phype_r,
              data=co15.c,
              ties='efron',
              tt = function(x,t,...) x*log(t),
              na.action = na.omit, 
              x = TRUE, y = TRUE)

summary(cph2)




###############################################################################

cutmod <- list(NULL)
loglike <- data.frame(time=c(seq(from=1, to=365)))
for (k in 1:365) {
  cutmod[[k]] <- coxph(Surv(AGED, DIED) ~ DMAR_r + tt(DMAR_r),
                      data=co15.c, ties='efron',
                      tt=function(x,t,...){ifelse(t > k, x, 0)})
  loglike[k,2] <- cutmod[[k]]$loglik[2]
}

cutmod <- list(NULL)
loglike2 <- data.frame(time=c(seq(from=1, to=365)))
for (k in 1:365) {
  cutmod[[k]] <- coxph(Surv(AGED, DIED) ~ PREVIS_r + tt(PREVIS_r),
                       data=co15.c, ties='efron',
                       tt=function(x,t,...){ifelse(t > k, x, 0)})
  loglike2[k,2] <- cutmod[[k]]$loglik[2]
}


###############################################################################
memory.limit(size = 16926400)
###################################
# Calculate time transformations manually
###################################

# Import CSV for leaner dataset w/o attrib names
co15.s <- read.csv("Data/co15_r.csv", header=TRUE)
#co15.s <- co15.l



#################################################
# Recoding
#################################################
# convert categorical variables to factors
# BFACIL_r
unique(co15.s$BFACIL_r)
co15.s$BFACIL_r <- factor(co15.s$BFACIL_r,
                          levels = c( "Hospital",
                                      "Home(intended)/Birth Center",
                                      "Other"))
# MAGER9_r
unique(co15.s$MAGER9_r)
co15.s$MAGER9_r <- factor(co15.s$MAGER9_r,
                          levels = c("Under 15 years",
                                     "15-19 years",
                                     "20-24 years",
                                     "25-29 years",
                                     "30-34 years",
                                     "35-39 years",
                                     "40-44 years",
                                     "45-49 years",
                                     "50-54 years"))
co15.s$MAGER9_r <- relevel(co15.s$MAGER9_r, ref="20-24 years")

# MBSTATE_REC_r
unique(co15.s$MBSTATE_REC_r)
co15.s$MBSTATE_REC_r <- factor(co15.s$MBSTATE_REC_r,
                               levels = c("Born in the U.S.",
                                          "Born outside the U.S."))
co15.s$MBSTATE_REC_r <- relevel(co15.s$MBSTATE_REC_r, ref="Born in the U.S.")

# MRACE6_r
unique(co15.s$MRACE6_r)
co15.s$MRACE6_r <- factor(co15.s$MRACE6_r,
                          levels = c(  "White (only)",
                                       "Black (only)",
                                       "AIAN/NHOPI",
                                       "Asian (only)",
                                       "More than one race"))
co15.s$MRACE6_r <- relevel(co15.s$MRACE6_r, ref="White (only)")

# MRACEHISP_r
unique(co15.s$MRACEHISP_r)
co15.s$MRACEHISP_r <- factor(co15.s$MRACEHISP_r,
                             levels = c( "White",
                                         "Black",
                                         "AIAN/NHOPI",
                                         "Asian",
                                         "Hispanic",
                                         "more than one race"))
co15.s$MRACEHISP_r <- relevel(co15.s$MRACEHISP_r, ref="White")

# DMAR_r
unique(co15.s$DMAR_r)
co15.s$DMAR_r <- factor(co15.s$DMAR_r,
                        levels = c("Married", "Unmarried"))
co15.s$DMAR_r <- relevel(co15.s$DMAR_r, ref="Married")

# MEDUC_r
unique(co15.s$MEDUC_r)
co15.s$MEDUC_r <- factor(co15.s$MEDUC_r,
                         levels = c( "8th grade or less",
                                     "9th-12th grade, no diploma",
                                     "High school diploma",
                                     "Some college, no degree",
                                     "Associate degree",
                                     "Bachelor's degree",
                                     "Master's degree",
                                     "Doctorate/Professional"))
co15.s$MEDUC_r <- relevel(co15.s$MEDUC_r, ref="High school diploma")

# FAGE11_r
unique(co15.s$FAGE11_r)
co15.s$FAGE11_r <- factor(co15.s$FAGE11_r, 
                          levels = c("Under 15 yea",
                                     "15-19 years",
                                     "20-24 years",
                                     "25-29 years",
                                     "30-34 years",
                                     "35-39 years",
                                     "40-44 years",
                                     "45-49 years",
                                     "50-54 years"))
co15.s$FAGE11_r <- relevel(co15.s$FAGE11_r, ref="20-24 years")

# FRACEHISP_r
unique(co15.s$FRACEHISP_r)
co15.s$FRACEHISP_r <- factor(co15.s$FRACEHISP_r,
                             levels = c( "White",
                                         "Black",
                                         "AIAN/NHOPI",
                                         "Asian",
                                         "Hispanic",
                                         "more than one race"))
co15.s$FRACEHISP_r <- relevel(co15.s$FRACEHISP_r, ref="White")

# FEDUC_r
unique(co15.s$FEDUC_r)
co15.s$FEDUC_r <- factor(co15.s$FEDUC_r,
                         levels = c( "8th grade or less",
                                     "9th-12th grade, no diploma",
                                     "High school diploma",
                                     "Some college, no degree",
                                     "Associate degree",
                                     "Bachelor's degree",
                                     "Master's degree",
                                     "Doctorate/Professional"))
co15.s$FEDUC_r <- relevel(co15.s$FEDUC_r, ref="High school diploma")

# ILLB_R11_r
unique(co15.s$ILLB_R11_r)
co15.s$ILLB_R11_r <- factor(co15.s$ILLB_R11_r,
                            levels = c( "1st birth",
                                        "0-3 mo.",
                                        "4-11 mo.",
                                        "12-17 mo.",
                                        "18-23 mo.",
                                        "24-35 mo.",
                                        "over 36 mo."))
co15.s$ILLB_R11_r <- relevel(co15.s$ILLB_R11_r, ref="1st birth")

# PRECARE5_r
unique(co15.s$PRECARE5_r)
co15.s$PRECARE5_r <- factor(co15.s$PRECARE5_r,
                            levels = c( "1st to 3rd month",
                                        "4th to 6th month",
                                        "7th to final month",
                                        "No prenatal care"))
co15.s$PRECARE5_r <- relevel(co15.s$PRECARE5_r, ref="No prenatal care")

# ANOMALY
unique(co15.s$ANOMALY)
co15.s$ANOMALY[co15.s$ANOMALY == "Yes"] <- "ANOMALY"
co15.s$ANOMALY <- factor(co15.s$ANOMALY,
                         levels = c("No", "ANOMALY"))
co15.s$ANOMALY <- relevel(co15.s$ANOMALY, ref="No")

# CIG1_R_r
unique(co15.s$CIG1_R_r)
co15.s$CIG1_R_r[co15.s$CIG1_R_r == "1-5 cigarettes"] <- "1-5 cigarettes_CIG1_R_r"
co15.s$CIG1_R_r[co15.s$CIG1_R_r == "6-10 cigarettes"] <- "6-10 cigarettes_CIG1_R_r"
co15.s$CIG1_R_r[co15.s$CIG1_R_r == "more than 10 cigarettes"] <- "more than 10 cigarettes_CIG1_R_r"
co15.s$CIG1_R_r <- factor(co15.s$CIG1_R_r,
                          levels = c( "Nonsmoker",
                                      "1-5 cigarettes_CIG1_R_r",
                                      "6-10 cigarettes_CIG1_R_r",
                                      "more than 10 cigarettes_CIG1_R_r"))
co15.s$CIG1_R_r <- relevel(co15.s$CIG1_R_r, ref="Nonsmoker")

# CIG2_R_r
unique(co15.s$CIG2_R_r)
co15.s$CIG2_R_r[co15.s$CIG2_R_r == "1-5 cigarettes"] <- "1-5 cigarettes_CIG2_R_r"
co15.s$CIG2_R_r[co15.s$CIG2_R_r == "6-10 cigarettes"] <- "6-10 cigarettes_CIG2_R_r"
co15.s$CIG2_R_r[co15.s$CIG2_R_r == "more than 10 cigarettes"] <- "more than 10 cigarettes_CIG2_R_r"
co15.s$CIG2_R_r <- factor(co15.s$CIG2_R_r,
                          levels = c( "Nonsmoker",
                                      "1-5 cigarettes_CIG2_R_r",
                                      "6-10 cigarettes_CIG2_R_r",
                                      "more than 10 cigarettes_CIG2_R_r"))
co15.s$CIG2_R_r <- relevel(co15.s$CIG2_R_r, ref="Nonsmoker")

# CIG3_R_r
unique(co15.s$CIG3_R_r)
co15.s$CIG3_R_r[co15.s$CIG3_R_r == "1-5 cigarettes"] <- "1-5 cigarettes_CIG3_R_r"
co15.s$CIG3_R_r[co15.s$CIG3_R_r == "6-10 cigarettes"] <- "6-10 cigarettes_CIG3_R_r"
co15.s$CIG3_R_r[co15.s$CIG3_R_r == "more than 10 cigarettes"] <- "more than 10 cigarettes_CIG3_R_r"
co15.s$CIG3_R_r <- factor(co15.s$CIG3_R_r,
                          levels = c( "Nonsmoker",
                                      "1-5 cigarettes_CIG3_R_r",
                                      "6-10 cigarettes_CIG3_R_r",
                                      "more than 10 cigarettes_CIG3_R_r"))
co15.s$CIG3_R_r <- relevel(co15.s$CIG3_R_r, ref="Nonsmoker")

# ANY_CIG
unique(co15.s$ANY_CIG)
co15.s$ANY_CIG <- factor(co15.s$ANY_CIG,
                         levels = c( "Nonsmoker",
                                     "Smoker",
                                     "Smoker, quit"))
co15.s$ANY_CIG <- relevel(co15.s$ANY_CIG, ref="Nonsmoker")

# BMI_R_r
unique(co15.s$BMI_R_r)
co15.s$BMI_R_r <- factor(co15.s$BMI_R_r,
                         levels = c( "Underweight <18.5",
                                     "Normal 18.5-24.9",
                                     "Overweight 25.0-29.9",
                                     "Obesity I 35.0-39.9",
                                     "Obesity II 35.0-39.9",
                                     "Extreme Obesity III >=40.0"))
co15.s$BMI_R_r <- relevel(co15.s$BMI_R_r, ref="Normal 18.5-24.9")

# uRF_Diab_r
unique(co15.s$uRF_Diab_r)
co15.s$uRF_Diab_r[co15.s$uRF_Diab_r == "Yes"] <- "uRF_Diab_r"
co15.s$uRF_Diab_r <- factor(co15.s$uRF_Diab_r,
                            levels = c("uRF_Diab_r", "No"))
co15.s$uRF_Diab_r <- relevel(co15.s$uRF_Diab_r, ref="No")

# uRF_Chype_r
unique(co15.s$uRF_Chype_r)
co15.s$uRF_Chype_r[co15.s$uRF_Chype_r == "Yes"] <- "uRF_Chype_r"
co15.s$uRF_Chype_r <- factor(co15.s$uRF_Chype_r,
                             levels = c("uRF_Chype_r", "No"))
co15.s$uRF_Chype_r <- relevel(co15.s$uRF_Chype_r, ref="No")

# uRF_Phype_r
unique(co15.s$uRF_Phype_r)
co15.s$uRF_Phype_r[co15.s$uRF_Phype_r == "Yes"] <- "uRF_Phype_r"
co15.s$uRF_Phype_r <- factor(co15.s$uRF_Phype_r,
                             levels = c("uRF_Phype_r", "No"))
co15.s$uRF_Phype_r <- relevel(co15.s$uRF_Phype_r, ref="No")

# uRf_Ehype_r
unique(co15.s$uRf_Ehype_r)
co15.s$uRf_Ehype_r[co15.s$uRf_Ehype_r == "Yes"] <- "uRf_Ehype_r"
co15.s$uRf_Ehype_r <- factor(co15.s$uRf_Ehype_r,
                             levels = c("uRf_Ehype_r", "No"))
co15.s$uRf_Ehype_r <- relevel(co15.s$uRf_Ehype_r, ref="No")

# uLD_Bree_r
unique(co15.s$uLD_Bree_r)
co15.s$uLD_Bree_r[co15.s$uLD_Bree_r == "Yes"] <- "uLD_Bree_r"
co15.s$uLD_Bree_r <- factor(co15.s$uLD_Bree_r,
                            levels = c("uLD_Bree_r", "No"))
co15.s$uLD_Bree_r <- relevel(co15.s$uLD_Bree_r, ref="No")

# PAY_r
unique(co15.s$PAY_r)
co15.s$PAY_r <- factor(co15.s$PAY_r,
                       levels = c("Private Insurance/Other", 
                                  "Medicaid/IHS"))
co15.s$PAY_r <- relevel(co15.s$PAY_r, ref="Private Insurance/Other")

# DPLURAL_r
unique(co15.s$DPLURAL_r)
co15.s$DPLURAL_r <- factor(co15.s$DPLURAL_r,
                           levels = c( "Single",
                                       "Multiple"))
co15.s$DPLURAL_r <- relevel(co15.s$DPLURAL_r, ref="Single")

# SEX_r
unique(co15.s$SEX_r)
co15.s$SEX_r <- factor(co15.s$SEX_r,
                       levels = c( "Female",
                                   "Male"))
co15.s$SEX_r <- relevel(co15.s$SEX_r, ref="Female")

# BWTR4_r
unique(co15.s$BWTR4_r)
co15.s$BWTR4_r <- factor(co15.s$BWTR4_r,
                         levels = c( "2500 - 8165 grams",
                                     "1500 - 2499 grams",
                                     "227 - 1499 grams"))
co15.s$BWTR4_r <- relevel(co15.s$BWTR4_r, ref="2500 - 8165 grams")

# BFED_r
unique(co15.s$BFED_r)
co15.s$BFED_r[co15.s$BFED_r == "No"] <- "BFED_r"
co15.s$BFED_r <- factor(co15.s$BFED_r,
                        levels = c( "Yes",
                                    "BFED_r"))
co15.s$BFED_r <- relevel(co15.s$BFED_r, ref="Yes")

# TBO_REC_r
unique(co15.s$TBO_REC_r)
co15.s$TBO_REC_r <- factor(co15.s$TBO_REC_r,
                           levels = c( "1 total birth order",
                                       "2 total birth order",
                                       "3 total birth order",
                                       "4 total birth order",
                                       "5 total birth order",
                                       "6 total birth order",
                                       "7 or more total births"))
co15.s$TBO_REC_r <- relevel(co15.s$TBO_REC_r, ref="1 total birth order")

# uCA_Anen_r
unique(co15.s$uCA_Anen_r)
co15.s$uCA_Anen_r[co15.s$uCA_Anen_r == "Yes"] <- "uCA_Anen_r"
co15.s$uCA_Anen_r <- factor(co15.s$uCA_Anen_r,
                            levels = c("No", "uCA_Anen_r"))
co15.s$uCA_Anen_r <- relevel(co15.s$uCA_Anen_r, ref="No")

# uCA_Spina_r
unique(co15.s$uCA_Spina_r)
co15.s$uCA_Spina_r[co15.s$uCA_Spina_r == "Yes"] <- "uCA_Spina_r"
co15.s$uCA_Spina_r <- factor(co15.s$uCA_Spina_r,
                             levels = c("No", "uCA_Spina_r"))
co15.s$uCA_Spina_r <- relevel(co15.s$uCA_Spina_r, ref="No")

# uCA_Omph_r
unique(co15.s$uCA_Omph_r)
co15.s$uCA_Omph_r[co15.s$uCA_Omph_r == "Yes"] <- "uCA_Omph_r"
co15.s$uCA_Omph_r <- factor(co15.s$uCA_Omph_r,
                            levels = c("No", "uCA_Omph_r"))
co15.s$uCA_Omph_r <- relevel(co15.s$uCA_Omph_r, ref="No")

# uCA_Hern_r
unique(co15.s$uCA_Hern_r)
co15.s$uCA_Hern_r[co15.s$uCA_Hern_r == "Yes"] <- "uCA_Hern_r"
co15.s$uCA_Hern_r <- factor(co15.s$uCA_Hern_r,
                            levels = c("No", "uCA_Hern_r"))
co15.s$uCA_Hern_r <- relevel(co15.s$uCA_Hern_r, ref="No")

# uCA_Down_r
unique(co15.s$uCA_Down_r)
co15.s$uCA_Down_r[co15.s$uCA_Down_r == "Yes"] <- "uCA_Down_r"
co15.s$uCA_Down_r <- factor(co15.s$uCA_Down_r,
                            levels = c("No", "uCA_Down_r"))
co15.s$uCA_Down_r <- relevel(co15.s$uCA_Down_r, ref="No")


# PRIORLIVE_r
unique(co15.s$PRIORLIVE_r)
co15.s$PRIORLIVE_r[co15.s$PRIORLIVE_r == "1"] <- "1_PRIORLIVE_r"
co15.s$PRIORLIVE_r[co15.s$PRIORLIVE_r == "2"] <- "2_PRIORLIVE_r"
co15.s$PRIORLIVE_r[co15.s$PRIORLIVE_r == "3"] <- "3_PRIORLIVE_r"
co15.s$PRIORLIVE_r[co15.s$PRIORLIVE_r == "4"] <- "4_PRIORLIVE_r"
co15.s$PRIORLIVE_r[co15.s$PRIORLIVE_r == "5"] <- "5_PRIORLIVE_r"
co15.s$PRIORLIVE_r[co15.s$PRIORLIVE_r == "6"] <- "6_PRIORLIVE_r"
co15.s$PRIORLIVE_r[co15.s$PRIORLIVE_r == "more than 6"] <- "more than 6_PRIORLIVE_r"
co15.s$PRIORLIVE_r <- factor(co15.s$PRIORLIVE_r,
                             levels = c( "0",
                                         "1_PRIORLIVE_r",
                                         "2_PRIORLIVE_r",
                                         "3_PRIORLIVE_r",
                                         "4_PRIORLIVE_r",
                                         "5_PRIORLIVE_r",
                                         "6_PRIORLIVE_r",
                                         "more than 6_PRIORLIVE_r"))
co15.s$PRIORLIVE_r <- relevel(co15.s$PRIORLIVE_r, ref="0")

# PRIORDEAD_r
unique(co15.s$PRIORDEAD_r)
co15.s$PRIORDEAD_r[co15.s$PRIORDEAD_r == "1"] <- "1_PRIORDEAD_r"
co15.s$PRIORDEAD_r[co15.s$PRIORDEAD_r == "2"] <- "2_PRIORDEAD_r"
co15.s$PRIORDEAD_r[co15.s$PRIORDEAD_r == "3"] <- "3_PRIORDEAD_r"
co15.s$PRIORDEAD_r[co15.s$PRIORDEAD_r == "more than 3"] <- "more than 3_PRIORDEAD_r"
co15.s$PRIORDEAD_r <- factor(co15.s$PRIORDEAD_r,
                             levels = c( "0",
                                         "1_PRIORDEAD_r",
                                         "2_PRIORDEAD_r",
                                         "3_PRIORDEAD_r",
                                         "more than 3_PRIORDEAD_r"))
co15.s$PRIORDEAD_r <- relevel(co15.s$PRIORDEAD_r, ref="0")

# PRIORTERM_r
unique(co15.s$PRIORTERM_r)
co15.s$PRIORTERM_r[co15.s$PRIORTERM_r == "1"] <- "1_PRIORTERM_r"
co15.s$PRIORTERM_r[co15.s$PRIORTERM_r == "2"] <- "2_PRIORTERM_r"
co15.s$PRIORTERM_r[co15.s$PRIORTERM_r == "more than 2"] <- "more than 2_PRIORTERM_r"
co15.s$PRIORTERM_r <- factor(co15.s$PRIORTERM_r,
                             levels = c( "0",
                                         "1_PRIORTERM_r",
                                         "2_PRIORTERM_r",
                                         "more than 2_PRIORTERM_r"))
co15.s$PRIORTERM_r <- relevel(co15.s$PRIORTERM_r, ref="0")

# PREVIS_r
unique(co15.s$PREVIS_r)
co15.s$PREVIS_r <- factor(co15.s$PREVIS_r,
                          levels = c( "0",
                                      "less than 10",
                                      "10-15",
                                      "more than 15"))
co15.s$PREVIS_r <- relevel(co15.s$PREVIS_r, ref="0")

# COMBGEST_r
unique(co15.s$COMBGEST_r)
co15.s$COMBGEST_r <- factor(co15.s$COMBGEST_r,
                            levels = c( "under 20 weeks",
                                        "20-24 weeks",
                                        "25-29 weeks",
                                        "30-34 weeks",
                                        "35-36 weeks",
                                        "37-38 weeks",
                                        "39 weeks",
                                        "40 weeks",
                                        "41 weeks",
                                        "over 41 weeks"))
co15.s$COMBGEST_r <- relevel(co15.s$COMBGEST_r, ref="39 weeks")


# AGED
sort(unique(co15.s$AGED), decreasing=FALSE)
co15.s$AGED[is.na(co15.s$AGED) & co15.s$DIED == 0] <- 364
co15.s$AGED[co15.s$AGED == 0] <- 0.2
co15.s$AGED[co15.s$AGED == 1] <- 1.2



######################################
# Convert to Dummy Coding
########################################
co15.d <- within(co15.s, rm(FEDUC_r, FRACEHISP_r, MRACEHISP_r, FAGE11_r,
                            uCA_Anen_r, uCA_Spina_r, uCA_Omph_r, uCA_Hern_r, uCA_Down_r,
                            BRTHWGT_r, COMBGEST, BMI_rC))
co15.d <- co15.d[complete.cases(co15.d), ]

co15.d$ind <- 1
co15.d$id <- seq(from=1, to=nrow(co15.d))


co15.d <- co15.d %>% 
  pivot_wider(names_from=BFACIL_r, values_from=ind)
co15.d <- dplyr::select(co15.d, -c(Hospital))
co15.d$'Home(intended)/Birth Center'[is.na(co15.d$'Home(intended)/Birth Center')] <- 0
co15.d$Other[is.na(co15.d$Other)] <- 0
co15.d$ind <- 1

co15.d <- co15.d %>% 
  pivot_wider(names_from=MAGER9_r, values_from=ind) 
co15.d <- dplyr::select(co15.d, -c(`20-24 years`))
co15.d$`25-29 years`[is.na(co15.d$`25-29 years`)] <- 0
co15.d$`30-34 years`[is.na(co15.d$`30-34 years`)] <- 0
co15.d$`35-39 years`[is.na(co15.d$`35-39 years`)] <- 0
co15.d$`15-19 years`[is.na(co15.d$`15-19 years`)] <- 0
co15.d$`40-44 years`[is.na(co15.d$`40-44 years`)] <- 0
co15.d$`45-49 years`[is.na(co15.d$`45-49 years`)] <- 0
co15.d$`Under 15 years`[is.na(co15.d$`Under 15 years`)] <- 0
co15.d$`50-54 years`[is.na(co15.d$`50-54 years`)] <- 0
co15.d$ind <- 1

co15.d <- co15.d %>% 
  pivot_wider(names_from=MBSTATE_REC_r, values_from=ind)
co15.d <- dplyr::select(co15.d, -c(`Born outside the U.S.`))
co15.d$`Born in the U.S.`[is.na(co15.d$`Born in the U.S.`)] <- 0
co15.d$ind <- 1

co15.d <- co15.d %>% 
  pivot_wider(names_from=MRACE6_r, values_from=ind)
co15.d <- dplyr::select(co15.d, -c(`White (only)`))
co15.d[is.na(co15.d)] <- 0 
co15.d$ind <- 1

co15.d <- co15.d %>% 
  pivot_wider(names_from=DMAR_r, values_from=ind)
co15.d <- dplyr::select(co15.d, -c(Married))
co15.d[is.na(co15.d)] <- 0 
co15.d$ind <- 1

co15.d <- co15.d %>% pivot_wider(names_from=MEDUC_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c('High school diploma'))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=TBO_REC_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c('1 total birth order'))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=ILLB_R11_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c('1st birth'))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=PRECARE5_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c('No prenatal care'))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=PREVIS_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c('0'))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=ANY_CIG, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c(Nonsmoker))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=PAY_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c('Private Insurance/Other'))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=DPLURAL_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c(Single))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=SEX_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c(Female))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=BWTR4_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c('2500 - 8165 grams'))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=ANOMALY, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c(No))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=BFED_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c(Yes))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=COMBGEST_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c('39 weeks'))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=CIG1_R_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c(Nonsmoker))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=CIG2_R_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c(Nonsmoker))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=CIG3_R_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c(Nonsmoker))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=uRF_Diab_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c(No))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=uRF_Chype_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c(No))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=uRF_Phype_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c(No))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=uRf_Ehype_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c(No))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=uLD_Bree_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c(No))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=PRIORLIVE_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c('0'))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=PRIORDEAD_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c('0'))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=PRIORTERM_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c('0'))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1

co15.d <- co15.d %>% 	pivot_wider(names_from=BMI_R_r, values_from=ind)	
co15.d <- dplyr::select(co15.d, -c('Normal 18.5-24.9'))	
co15.d[is.na(co15.d)] <- 0	
co15.d$ind <- 1



co15.d <- co15.d %>% 
  rowwise() %>% 
  mutate(log.aged = log(AGED))

co15.d <- within(co15.d, rm(id,ind))

print(co15.d, width=Inf)


# Rename Variables
co15.d <- co15.d %>%
  rename(BFACIL_Home_intended = `Home(intended)/Birth Center`)
co15.d <- co15.d %>%
  rename(BFACIL_Other = Other) 
co15.d <- co15.d %>%
  rename(DMAR_Unmarried = Unmarried) 
co15.d <- co15.d %>%
  rename(PREVIS_less_than_10 = `less than 10`) 
co15.d <- co15.d %>%
  rename(PREVIS_10_15 = `10-15`) 
co15.d <- co15.d %>%
  rename(PREVIS_more_than_15 = `more than 15`) 
co15.d <- co15.d %>%
  rename(ANY.CIG_Smoker = Smoker)
co15.d <- co15.d %>%
  rename(ANY.CIG_Smoker_quit = `Smoker, quit`)
co15.d <- co15.d %>%
  rename(SEX_male = Male) 
co15.d <- co15.d %>%
  rename(BWTR4_1500_2499grams = `1500 - 2499 grams`)
co15.d <- co15.d %>%
  rename(BWTR4_227_1499grams = `227 - 1499 grams`)
co15.d <- co15.d %>%
  rename(COMBGEST_over_41_weeks = `over 41 weeks`) 
co15.d <- co15.d %>%
  rename(COMBGEST_41_weeks = `41 weeks`) 
co15.d <- co15.d %>%
  rename(COMBGEST_40_weeks = `40 weeks`) 
co15.d <- co15.d %>%
  rename(COMBGEST_37_38_weeks = `37-38 weeks`) 
co15.d <- co15.d %>%
  rename(COMBGEST_35_36_weeks = `35-36 weeks`) 
co15.d <- co15.d %>%
  rename(COMBGEST_25_29_weeks = `25-29 weeks`) 
co15.d <- co15.d %>%
  rename(COMBGEST_30_34_weeks = `30-34 weeks`) 
co15.d <- co15.d %>%
  rename(COMBGEST_under_20_weeks = `under 20 weeks`) 
co15.d <- co15.d %>%
  rename(COMBGEST_20_24_weeks = `20-24 weeks`)
co15.d <- co15.d %>%
  rename(BMI_Overweight = `Overweight 25.0-29.9`)
co15.d <- co15.d %>%
  rename(BMI_Obesity1 = `Obesity I 35.0-39.9`)
co15.d <- co15.d %>%
  rename(BMI_Obesity2 = `Obesity II 35.0-39.9`)
co15.d <- co15.d %>%
  rename(BMI_Underweight = `Underweight <18.5`)
co15.d <- co15.d %>%
  rename(BMI_Obesity3 = `Extreme Obesity III >=40.0`)



# Compute log time transforms
memory.limit(size = 16926400)
co15.d <- co15.d %>% 
  mutate(log.APGAR5_r = log.aged*APGAR5_r,
         log.DMAR_r = log.aged*DMAR_Unmarried,
         log.PREVIS_r1 = log.aged*PREVIS_less_than_10,
         log.PREVIS_r2 = log.aged*PREVIS_10_15,
         log.PREVIS_r3 = log.aged*PREVIS_more_than_15,
         log.ANY_CIG1 = log.aged*ANY.CIG_Smoker,
         log.ANY_CIG2 = log.aged*ANY.CIG_Smoker_quit,
         log.SEX = log.aged*SEX_male,
         log.BW2 = log.aged*BWTR4_1500_2499grams,
         log.BW1 = log.aged*BWTR4_227_1499grams,
         log.COMBGEST1 = log.aged*COMBGEST_under_20_weeks,
         log.COMBGEST2 = log.aged*COMBGEST_20_24_weeks,
         log.COMBGEST3 = log.aged*COMBGEST_25_29_weeks,
         log.COMBGEST4 = log.aged*COMBGEST_30_34_weeks,
         log.COMBGEST5 = log.aged*COMBGEST_35_36_weeks,
         log.COMBGEST6 = log.aged*COMBGEST_37_38_weeks,
         log.COMBGEST7 = log.aged*COMBGEST_40_weeks,
         log.COMBGEST8 = log.aged*COMBGEST_41_weeks,
         log.COMBGEST9 = log.aged*COMBGEST_over_41_weeks,
         log.BFED = log.aged*BFED_r,
         log.uRF_Phype = log.aged*uRF_Phype_r)


# Compute identity time transforms
co15.d <- co15.d %>% 
  mutate(t.APGAR5_r = AGED*APGAR5_r,
         t.DMAR_r = AGED*DMAR_Unmarried,
         t.PREVIS_r1 = AGED*PREVIS_less_than_10,
         t.PREVIS_r2 = AGED*PREVIS_10_15,
         t.PREVIS_r3 = AGED*PREVIS_more_than_15,
         t.ANY_CIG1 = AGED*ANY.CIG_Smoker,
         t.ANY_CIG2 = AGED*ANY.CIG_Smoker_quit,
         t.SEX = AGED*SEX_male,
         t.BW2 = AGED*BWTR4_1500_2499grams,
         t.BW1 = AGED*BWTR4_227_1499grams,
         t.COMBGEST1 = AGED*COMBGEST_under_20_weeks,
         t.COMBGEST2 = AGED*COMBGEST_20_24_weeks,
         t.COMBGEST3 = AGED*COMBGEST_25_29_weeks,
         t.COMBGEST4 = AGED*COMBGEST_30_34_weeks,
         t.COMBGEST5 = AGED*COMBGEST_35_36_weeks,
         t.COMBGEST6 = AGED*COMBGEST_37_38_weeks,
         t.COMBGEST7 = AGED*COMBGEST_40_weeks,
         t.COMBGEST8 = AGED*COMBGEST_41_weeks,
         t.COMBGEST9 = AGED*COMBGEST_over_41_weeks,
         t.BFED = AGED*BFED_r,
         t.uRF_Phype = AGED*uRF_Phype_r)


# Test proportional hazards assumption
assess.cph1id <- cox.zph(cph1, transform="identity", terms=TRUE, global=TRUE)
assess.cph1km <- cox.zph(cph1, transform="km", terms=TRUE, global=TRUE)
assess.cph1log <- cox.zph(cph1, transform="log", terms=TRUE, global=TRUE)

assess.cph1log$table

par(mfrow=c(3,3))
plot(assess.cph1log, col="red")

# APGAR5_r
m1a <- coxph(Surv(AGED, DIED) ~ 
                APGAR5_r + log.APGAR5_r,
             data=co15.d,
             ties='efron')
m1b <- coxph(Surv(AGED, DIED) ~ APGAR5_r,
             data = co15.d, ties = 'efron')
summary(m1a)
anova(m1a, m1b)
( lik1 <- -2*(logLik(m1b) - logLik(m1a)) )
pchisq(lik1, df=1)

# DMAR_Unmarried
m2a <- coxph(Surv(AGED, DIED) ~ DMAR_Unmarried + log.DMAR_r,
             data = co15.d, ties = 'efron')
m2b <- coxph(Surv(AGED, DIED) ~ DMAR_Unmarried,
             data = co15.d, ties = 'efron')
summary(m2a)
anova(m2a, m2b)

# PREVIS_r
m3a <- coxph(Surv(AGED, DIED) ~ 
               PREVIS_less_than_10 + log.PREVIS_r1 +
               PREVIS_10_15 + log.PREVIS_r2 +
               PREVIS_more_than_15 + log.PREVIS_r3,
             data = co15.d, ties = 'efron')
m3b <- coxph(Surv(AGED, DIED) ~ PREVIS_less_than_10 + PREVIS_10_15 + PREVIS_more_than_15,
             data = co15.d, ties = 'efron')
summary(m3a)
anova(m3a, m3b)

# ANY_CIG
m7a <- coxph(Surv(AGED, DIED) ~ 
               ANY.CIG_Smoker + log.ANY_CIG1 + 
               ANY.CIG_Smoker_quit + log.ANY_CIG2,
             data = co15.d, ties = 'efron')
m7b <- coxph(Surv(AGED, DIED) ~ ANY.CIG_Smoker + ANY.CIG_Smoker_quit,
             data = co15.d, ties = 'efron')
summary(m7a)
anova(m7a, m7b)

# BWTR4_r
m8a <- coxph(Surv(AGED, DIED) ~ BWTR4_1500_2499grams + log.BW2 + BWTR4_227_1499grams + log.BW1,
             data = co15.d, ties = 'efron')
m8b <- coxph(Surv(AGED, DIED) ~ BWTR4_1500_2499grams + BWTR4_227_1499grams,
             data = co15.d, ties = 'efron')
summary(m8a)
anova(m8a, m8b)

# BFED_r
m4a <- coxph(Surv(AGED, DIED) ~ BFED_r + log.BFED,
             data = co15.d, ties = 'efron')
m4b <- coxph(Surv(AGED, DIED) ~ BFED_r,
             data = co15.d, ties = 'efron')
summary(m4a)
anova(m4a, m4b)

# COMBGEST_r
m5a <- coxph(Surv(AGED, DIED) ~ 
               COMBGEST_over_41_weeks + log.COMBGEST9 + 
               COMBGEST_41_weeks + log.COMBGEST8 + 
               COMBGEST_40_weeks + log.COMBGEST7 +
               COMBGEST_37_38_weeks + log.COMBGEST6 + 
               COMBGEST_35_36_weeks + log.COMBGEST5 +
               COMBGEST_25_29_weeks + log.COMBGEST3 + 
               COMBGEST_30_34_weeks + log.COMBGEST4 + 
               COMBGEST_under_20_weeks + log.COMBGEST1 +
               COMBGEST_20_24_weeks + log.COMBGEST2,
             data = co15.d, ties = 'efron')
m5b <- coxph(Surv(AGED, DIED) ~ 
               COMBGEST_over_41_weeks +
               COMBGEST_41_weeks +
               COMBGEST_40_weeks +
               COMBGEST_37_38_weeks +
               COMBGEST_35_36_weeks + 
               COMBGEST_25_29_weeks +
               COMBGEST_30_34_weeks +
               COMBGEST_under_20_weeks + 
               COMBGEST_20_24_weeks,
             data = co15.d, ties = 'efron')
summary(m5a)
anova(m5a, m5b)

# SEX_male
m6a <- coxph(Surv(AGED, DIED) ~ SEX_male + log.SEX,
             data = co15.d, ties = 'efron')
m6b <- coxph(Surv(AGED, DIED) ~ SEX_male,
             data = co15.d, ties = 'efron')
summary(m6a)
anova(m6a, m6b)

# uRF_Phype_r
m9a <- coxph(Surv(AGED, DIED) ~ uRF_Phype_r + log.uRF_Phype,
             data = co15.d, ties = 'efron')
m9b <- coxph(Surv(AGED, DIED) ~ uRF_Phype_r,
             data = co15.d, ties = 'efron')
summary(m9a)
anova(m9a, m9b)




####################################################################
# Fit cox proportional hazards model with time-dependent covariates
####################################################################
cph3 <- coxph(Surv(AGED, DIED) ~ 
                APGAR5_r + log.APGAR5_r +
                BFACIL_Home_intended +
                BFACIL_Other +
                DMAR_Unmarried + log.DMAR_r +
                PREVIS_less_than_10 + log.PREVIS_r1 + 
                PREVIS_10_15 + log.PREVIS_r2 +
                PREVIS_more_than_15 + log.PREVIS_r3 +
                ANY.CIG_Smoker + log.ANY_CIG1 + 
                ANY.CIG_Smoker_quit + log.ANY_CIG2 +
                SEX_male + log.SEX +
                BWTR4_1500_2499grams + log.BW2 + 
                BWTR4_227_1499grams + log.BW1 + 
                ANOMALY +
                BFED_r + log.BFED + 
                COMBGEST_over_41_weeks + log.COMBGEST9 + 
                COMBGEST_41_weeks + log.COMBGEST8 + 
                COMBGEST_40_weeks + log.COMBGEST7 +
                COMBGEST_37_38_weeks + log.COMBGEST6 + 
                COMBGEST_35_36_weeks + log.COMBGEST5 +
                COMBGEST_25_29_weeks + log.COMBGEST3 + 
                COMBGEST_30_34_weeks + log.COMBGEST4 + 
                COMBGEST_under_20_weeks + log.COMBGEST1 +
                COMBGEST_20_24_weeks + log.COMBGEST2 + 
                uRF_Phype_r + log.uRF_Phype + 
                BMI_Overweight +
                BMI_Obesity1 +
                BMI_Obesity2 +
                BMI_Underweight +
                BMI_Obesity3,
            data=co15.d,
            ties='efron',
            x = TRUE, y = TRUE)

summary(cph3)

# Test proportional hazards assumption
assess.cph3id <- cox.zph(cph3, transform="identity", terms=TRUE, global=TRUE)
assess.cph3km <- cox.zph(cph3, transform="km", terms=TRUE, global=TRUE)
assess.cph3log <- cox.zph(cph3, transform="log", terms=FALSE, global=TRUE)

assess.cph3id$table





####################################################################
# Fit cox proportional hazards model with time-dependent covariates: 
# non-significant p-values dropped
####################################################################
cph4 <- coxph(Surv(AGED, DIED) ~ 
                APGAR5_r + log.APGAR5_r +
                BFACIL_Home_intended +
                BFACIL_Other +
                DMAR_Unmarried + log.DMAR_r +
                PREVIS_less_than_10 + log.PREVIS_r1 + 
                PREVIS_10_15 + log.PREVIS_r2 +
                PREVIS_more_than_15 + log.PREVIS_r3 +
                ANY.CIG_Smoker + 
                ANY.CIG_Smoker_quit +
                SEX_male + log.SEX +
                BWTR4_1500_2499grams + 
                BWTR4_227_1499grams +  
                ANOMALY +
                BFED_r + log.BFED + 
                COMBGEST_over_41_weeks + log.COMBGEST9 + 
                COMBGEST_41_weeks + log.COMBGEST8 + 
                COMBGEST_40_weeks + log.COMBGEST7 +
                COMBGEST_37_38_weeks + log.COMBGEST6 + 
                COMBGEST_35_36_weeks + log.COMBGEST5 +
                COMBGEST_25_29_weeks + log.COMBGEST3 + 
                COMBGEST_30_34_weeks + log.COMBGEST4 + 
                COMBGEST_under_20_weeks + log.COMBGEST1 +
                COMBGEST_20_24_weeks + log.COMBGEST2 + 
                uRF_Phype_r + log.uRF_Phype + 
                BMI_Overweight +
                BMI_Obesity1 +
                BMI_Obesity2 +
                BMI_Underweight +
                BMI_Obesity3,
              data=co15.d,
              ties='efron',
              x = TRUE, y = TRUE)

summary(cph4)


# Test proportional hazards assumption
assess.cph4id <- cox.zph(cph4, transform="identity", terms=TRUE, global=TRUE)
assess.cph4km <- cox.zph(cph4, transform="km", terms=TRUE, global=TRUE)
assess.cph4log <- cox.zph(cph4, transform="log", terms=TRUE, global=TRUE)

assess.cph4id$table

par(mfrow=c(3,3))
plot(assess.cph4id, col="red")



############################################
# Find cutpoints
############################################

# DMAR_Unmarried
DMAR.loglik <- NULL
co15.d$DMAR_Unmarried1 <- 0
co15.d$DMAR_Unmarried2 <- 0
DMAR_Unmarried1 <- 0
DMAR_Unmarried2 <- 0

for (k in 1:364) {
  DMAR_Unmarried2 <- ifelse(co15.d$AGED > k, 
                             DMAR_Unmarried2 <- co15.d$log.DMAR_r[co15.d$AGED > k],
                             ifelse(co15.d$AGED <= k, DMAR_Unmarried2 <- 0, w <- NA))
                      
  DMAR_Unmarried1 <- ifelse(co15.d$AGED <= k, 
                             DMAR_Unmarried1 <- co15.d$log.DMAR_r[co15.d$AGED <= k],
                             ifelse(co15.d$AGED > k, DMAR_Unmarried1 <- 0, w <- NA))
         
  co15.d$DMAR_Unmarried2 <- DMAR_Unmarried2
  co15.d$DMAR_Unmarried1 <- DMAR_Unmarried1
  
  DMAR.cph <- coxph(Surv(AGED, DIED) ~ DMAR_Unmarried1 + DMAR_Unmarried2,
                       data = co15.d, ties = 'efron')
  
  DMAR.loglik[k] <- DMAR.cph$loglik[2]
  
  co15.d$DMAR_Unmarried2 <- 0
  co15.d$DMAR_Unmarried1 <- 0
}

tau <- seq(from=1, to=364, by=1)
DMAR.tbl <- data.frame(tau=tau, log.partial.lik=DMAR.loglik)

# cutpoint that produces model with the maximum log likelihood
DMAR.cutpt <- DMAR.tbl$tau[DMAR.tbl$log.partial.lik == max(DMAR.tbl$log.partial.lik)]

# assign tau with max log likelihood as cutpoint for DMAR_unmarried
DMAR_Unmarried2 <- ifelse(co15.d$AGED > DMAR.cutpt,
                                 DMAR_Unmarried2 <- co15.d$log.DMAR_r[co15.d$AGED > DMAR.cutpt],
                                 ifelse(co15.d$AGED <= DMAR.cutpt, DMAR_Unmarried2 <- 0, w <- NA))

DMAR_Unmarried1 <- ifelse(co15.d$AGED <= DMAR.cutpt,
                                 DMAR_Unmarried1 <- co15.d$log.DMAR_r[co15.d$AGED <= DMAR.cutpt],
                                 ifelse(co15.d$AGED > DMAR.cutpt, DMAR_Unmarried1 <- 0, w <- NA))

co15.d$DMAR_Unmarried2 <- DMAR_Unmarried2
co15.d$DMAR_Unmarried1 <- DMAR_Unmarried1



####################################################################
# Fit cox proportional hazards model with time-dependent covariates: 
# non-significant p-values dropped, optimal cutpoint created for DMAR_Unmarried
####################################################################
cph5 <- coxph(Surv(AGED, DIED) ~ 
                APGAR5_r + log.APGAR5_r +
                BFACIL_Home_intended +
                BFACIL_Other +
                DMAR_Unmarried1 + DMAR_Unmarried2 +
                PREVIS_less_than_10 + log.PREVIS_r1 + 
                PREVIS_10_15 + log.PREVIS_r2 +
                PREVIS_more_than_15 + log.PREVIS_r3 +
                ANY.CIG_Smoker + 
                ANY.CIG_Smoker_quit +
                SEX_male + log.SEX +
                BWTR4_1500_2499grams + 
                BWTR4_227_1499grams +  
                ANOMALY +
                BFED_r + log.BFED + 
                COMBGEST_over_41_weeks + log.COMBGEST9 + 
                COMBGEST_41_weeks + log.COMBGEST8 + 
                COMBGEST_40_weeks + log.COMBGEST7 +
                COMBGEST_37_38_weeks + log.COMBGEST6 + 
                COMBGEST_35_36_weeks + log.COMBGEST5 +
                COMBGEST_25_29_weeks + log.COMBGEST3 + 
                COMBGEST_30_34_weeks + log.COMBGEST4 + 
                COMBGEST_under_20_weeks + log.COMBGEST1 +
                COMBGEST_20_24_weeks + log.COMBGEST2 + 
                uRF_Phype_r + log.uRF_Phype + 
                BMI_Overweight +
                BMI_Obesity1 +
                BMI_Obesity2 +
                BMI_Underweight +
                BMI_Obesity3,
              data=co15.d,
              ties='efron',
              x = TRUE, y = TRUE)

summary(cph5)

# Test proportional hazards assumption
assess.cph5id <- cox.zph(cph5, transform="identity", terms=TRUE, global=TRUE)
assess.cph5km <- cox.zph(cph5, transform="km", terms=TRUE, global=TRUE)
assess.cph5log <- cox.zph(cph5, transform="log", terms=TRUE, global=TRUE)

assess.cph5log$table

# DMAR_Unmarried
m2a <- coxph(Surv(AGED, DIED) ~ DMAR_Unmarried1 + DMAR_Unmarried2,
             data = co15.d, ties = 'efron')
summary(m2a)
cox.zph(m2a, transform="log", terms=TRUE, global=TRUE)
# it is necessary to find another cutpoint on the interval (0, 362)




############################################
# Find 2nd Cutpoint
############################################

# DMAR_Unmarried
DMAR.loglik2 <- NULL
co15.d$DMAR_Unmarried3 <- 0
co15.d$DMAR_Unmarried4 <- 0
DMAR_Unmarried3 <- 0
DMAR_Unmarried4 <- 0

for (k in 1:362) {
  DMAR_Unmarried3 <- ifelse(co15.d$AGED > k & co15.d$AGED <= 362, 
                            DMAR_Unmarried3 <- co15.d$log.DMAR_r[co15.d$AGED > k],
                            DMAR_Unmarried3 <- 0)
  
  DMAR_Unmarried4 <- ifelse(co15.d$AGED <= k, 
                            DMAR_Unmarried4 <- co15.d$log.DMAR_r[co15.d$AGED <= k],
                            DMAR_Unmarried4 <- 0)
  
  co15.d$DMAR_Unmarried3 <- DMAR_Unmarried3
  co15.d$DMAR_Unmarried4 <- DMAR_Unmarried4
  
  DMAR.cph <- coxph(Surv(AGED, DIED) ~ DMAR_Unmarried2 + DMAR_Unmarried3 + DMAR_Unmarried4,
                    data = co15.d, ties = 'efron', iter.max = 100)
  
  DMAR.loglik2[k] <- DMAR.cph$loglik[2]
  
  co15.d$DMAR_Unmarried3 <- 0
  co15.d$DMAR_Unmarried4 <- 0
}

tau2 <- seq(from=1, to=362, by=1)
DMAR.tbl2 <- data.frame(tau=tau2, log.partial.lik=DMAR.loglik2)

# cutpoint that produces model with the maximum log likelihood
DMAR.cutpt2 <- DMAR.tbl2$tau[DMAR.tbl2$log.partial.lik == max(DMAR.tbl2$log.partial.lik)]

# assign tau with max log likelihood as cutpoint for DMAR_unmarried
DMAR_Unmarried3 <- ifelse(co15.d$AGED > DMAR.cutpt2 & co15.d$AGED <= DMAR.cutpt,
                          DMAR_Unmarried3 <- co15.d$log.DMAR_r[co15.d$AGED > DMAR.cutpt2 
                                                               & co15.d$AGED <= DMAR.cutpt],
                          DMAR_Unmarried3 <- 0)

DMAR_Unmarried4 <- ifelse(co15.d$AGED <= DMAR.cutpt2,
                          DMAR_Unmarried4 <- co15.d$log.DMAR_r[co15.d$AGED <= DMAR.cutpt2],
                          DMAR_Unmarried4 <- 0)

co15.d$DMAR_Unmarried3 <- DMAR_Unmarried3
co15.d$DMAR_Unmarried4 <- DMAR_Unmarried4




####################################################################
# Fit cox proportional hazards model with time-dependent covariates: 
# 2nd cutpoint created for DMAR_Unmarried
####################################################################
cph6 <- coxph(Surv(AGED, DIED) ~ 
                APGAR5_r + log.APGAR5_r +
                BFACIL_Home_intended +
                BFACIL_Other +
                DMAR_Unmarried2 + DMAR_Unmarried3 + DMAR_Unmarried4 +
                PREVIS_less_than_10 + log.PREVIS_r1 + 
                PREVIS_10_15 + log.PREVIS_r2 +
                PREVIS_more_than_15 + log.PREVIS_r3 +
                ANY.CIG_Smoker + 
                ANY.CIG_Smoker_quit +
                SEX_male + log.SEX +
                BWTR4_1500_2499grams + 
                BWTR4_227_1499grams +  
                ANOMALY +
                BFED_r + log.BFED + 
                COMBGEST_over_41_weeks + log.COMBGEST9 + 
                COMBGEST_41_weeks + log.COMBGEST8 + 
                COMBGEST_40_weeks + log.COMBGEST7 +
                COMBGEST_37_38_weeks + log.COMBGEST6 + 
                COMBGEST_35_36_weeks + log.COMBGEST5 +
                COMBGEST_25_29_weeks + log.COMBGEST3 + 
                COMBGEST_30_34_weeks + log.COMBGEST4 + 
                COMBGEST_under_20_weeks + log.COMBGEST1 +
                COMBGEST_20_24_weeks + log.COMBGEST2 + 
                uRF_Phype_r + log.uRF_Phype + 
                BMI_Overweight +
                BMI_Obesity1 +
                BMI_Obesity2 +
                BMI_Underweight +
                BMI_Obesity3,
              data=co15.d,
              ties='efron',
              x = TRUE, y = TRUE)

summary(cph6)

# Test proportional hazards assumption
assess.cph6log <- cox.zph(cph6, transform="log", terms=TRUE, global=TRUE)

assess.cph6log$table

m2a <- coxph(Surv(AGED, DIED) ~ DMAR_Unmarried2 + DMAR_Unmarried3 + DMAR_Unmarried4 +
               I(DMAR_Unmarried2*log(AGED)) + I(DMAR_Unmarried3*log(AGED)) + I(DMAR_Unmarried4*log(AGED)),
             data = co15.d, ties = 'efron')
summary(m2a)




############################################
# Find 3rd Cutpoint
############################################

# DMAR_Unmarried
DMAR.loglik3 <- NULL
co15.d$DMAR_Unmarried5 <- 0
co15.d$DMAR_Unmarried6 <- 0
DMAR_Unmarried5 <- 0
DMAR_Unmarried6 <- 0

for (k in 2:362) {
  DMAR_Unmarried5 <- ifelse(co15.d$AGED <= k & co15.d$AGED > 1, 
                            DMAR_Unmarried5 <- co15.d$log.DMAR_r[co15.d$AGED <= k & co15.d$AGED > 1],
                            DMAR_Unmarried5 <- 0)
  
  DMAR_Unmarried6 <- ifelse(co15.d$AGED > k & co15.d$AGED <= 362, 
                            DMAR_Unmarried6 <- co15.d$log.DMAR_r[co15.d$AGED > k & co15.d$AGED < 362],
                            DMAR_Unmarried6 <- 0)
  
  co15.d$DMAR_Unmarried5 <- DMAR_Unmarried5
  co15.d$DMAR_Unmarried6 <- DMAR_Unmarried6
  
  DMAR.cph <- coxph(Surv(AGED, DIED) ~ DMAR_Unmarried2 + DMAR_Unmarried4 + 
                      DMAR_Unmarried5 + DMAR_Unmarried6,
                    data = co15.d, ties = 'efron', iter.max = 100)
  
  DMAR.loglik3[k] <- DMAR.cph$loglik[2]
  
  co15.d$DMAR_Unmarried5 <- 0
  co15.d$DMAR_Unmarried6 <- 0
}

tau3 <- seq(from=2, to=362, by=1)
DMAR.tbl3 <- data.frame(tau=tau3, log.partial.lik=DMAR.loglik3[2:362])

# cutpoint that produces model with the maximum log likelihood
DMAR.cutpt3 <- DMAR.tbl3$tau[DMAR.tbl3$log.partial.lik == max(DMAR.tbl3$log.partial.lik)]

# assign tau with max log likelihood as cutpoint for DMAR_unmarried
DMAR_Unmarried5 <- ifelse(co15.d$AGED <= DMAR.cutpt3 & co15.d$AGED > 1, 
                          DMAR_Unmarried5 <- co15.d$log.DMAR_r[co15.d$AGED <= DMAR.cutpt3 
                                                               & co15.d$AGED > 1],
                          DMAR_Unmarried5 <- 0)

DMAR_Unmarried6 <- ifelse(co15.d$AGED > DMAR.cutpt3 & co15.d$AGED <= 362, 
                          DMAR_Unmarried6 <- co15.d$log.DMAR_r[co15.d$AGED > DMAR.cutpt3
                                                               & co15.d$AGED < 362],
                          DMAR_Unmarried6 <- 0)

co15.d$DMAR_Unmarried5 <- DMAR_Unmarried5
co15.d$DMAR_Unmarried6 <- DMAR_Unmarried6




####################################################################
# Fit cox proportional hazards model with time-dependent covariates: 
# 3 Cutpoints
####################################################################
cph7 <- coxph(Surv(AGED, DIED) ~ 
                APGAR5_r + log.APGAR5_r +
                BFACIL_Home_intended +
                BFACIL_Other +
                DMAR_Unmarried2 + DMAR_Unmarried4 + DMAR_Unmarried5 + DMAR_Unmarried6 +
                PREVIS_less_than_10 + log.PREVIS_r1 + 
                PREVIS_10_15 + log.PREVIS_r2 +
                PREVIS_more_than_15 + log.PREVIS_r3 +
                ANY.CIG_Smoker + 
                ANY.CIG_Smoker_quit +
                SEX_male + log.SEX +
                BWTR4_1500_2499grams + 
                BWTR4_227_1499grams +  
                ANOMALY +
                BFED_r + log.BFED + 
                COMBGEST_over_41_weeks + log.COMBGEST9 + 
                COMBGEST_41_weeks + log.COMBGEST8 + 
                COMBGEST_40_weeks + log.COMBGEST7 +
                COMBGEST_37_38_weeks + log.COMBGEST6 + 
                COMBGEST_35_36_weeks + log.COMBGEST5 +
                COMBGEST_25_29_weeks + log.COMBGEST3 + 
                COMBGEST_30_34_weeks + log.COMBGEST4 + 
                COMBGEST_under_20_weeks + log.COMBGEST1 +
                COMBGEST_20_24_weeks + log.COMBGEST2 + 
                uRF_Phype_r + log.uRF_Phype + 
                BMI_Overweight +
                BMI_Obesity1 +
                BMI_Obesity2 +
                BMI_Underweight +
                BMI_Obesity3,
              data=co15.d,
              ties='efron',
              x = TRUE, y = TRUE,
              iter.max = 100)

summary(cph7)

# Test proportional hazards assumption
assess.cph7log <- cox.zph(cph7, transform="log", terms=TRUE, global=TRUE)

assess.cph7log$table

m2a <- coxph(Surv(AGED, DIED) ~ 
               DMAR_Unmarried2 + DMAR_Unmarried4 + DMAR_Unmarried5 + DMAR_Unmarried6 +
               I(DMAR_Unmarried2*log(AGED)) + I(DMAR_Unmarried4*log(AGED)) +
               I(DMAR_Unmarried5*log(AGED)) + I(DMAR_Unmarried6*log(AGED)),
             data = co15.d, ties = 'efron')
summary(m2a)




############################################
# Find 4th and 5th Cutpoints
############################################

# DMAR_Unmarried
DMAR.loglik4 <- NULL
co15.d$DMAR_Unmarried7 <- 0
co15.d$DMAR_Unmarried8 <- 0
co15.d$DMAR_Unmarried9 <- 0
co15.d$DMAR_Unmarried10 <- 0
DMAR_Unmarried7 <- 0
DMAR_Unmarried8 <- 0
DMAR_Unmarried9 <- 0
DMAR_Unmarried10 <- 0
tau.j <- NULL
tau.k <- NULL
count <- 0

for(j in 21:361) {
  DMAR_Unmarried7 <- ifelse(co15.d$AGED <= j & co15.d$AGED > 20, 
                            DMAR_Unmarried7 <- co15.d$log.DMAR_r[co15.d$AGED <= j & co15.d$AGED > 20],
                            DMAR_Unmarried7 <- 0)
  
  DMAR_Unmarried8 <- ifelse(co15.d$AGED > j & co15.d$AGED < 362, 
                            DMAR_Unmarried8 <- co15.d$log.DMAR_r[co15.d$AGED > j & co15.d$AGED < 362],
                            DMAR_Unmarried8 <- 0)
  
  co15.d$DMAR_Unmarried7 <- DMAR_Unmarried7
  co15.d$DMAR_Unmarried8 <- DMAR_Unmarried8
  
  for(k in 2:19){
    DMAR_Unmarried9 <- ifelse(co15.d$AGED <= k & co15.d$AGED > 1, 
                              DMAR_Unmarried9 <- co15.d$log.DMAR_r[co15.d$AGED <= k & co15.d$AGED > 1],
                              DMAR_Unmarried9 <- 0)
    
    DMAR_Unmarried10 <- ifelse(co15.d$AGED > k & co15.d$AGED < 20, 
                               DMAR_Unmarried10 <- co15.d$log.DMAR_r[co15.d$AGED > k & co15.d$AGED < 20],
                               DMAR_Unmarried10 <- 0)
    
    co15.d$DMAR_Unmarried9 <- DMAR_Unmarried9
    co15.d$DMAR_Unmarried10 <- DMAR_Unmarried10
    
    DMAR.cph <- coxph(Surv(AGED, DIED) ~ DMAR_Unmarried2 + DMAR_Unmarried4 + DMAR_Unmarried7 + 
                        DMAR_Unmarried8 + DMAR_Unmarried9 + DMAR_Unmarried10,
                      data = co15.d, ties = 'efron', iter.max = 300)
    
    count <- count + 1
    DMAR.loglik4[count] <- DMAR.cph$loglik[2]
    tau.j[count] <- j
    tau.k[count] <- k
    
    co15.d$DMAR_Unmarried7 <- 0
    co15.d$DMAR_Unmarried8 <- 0
    co15.d$DMAR_Unmarried9 <- 0
    co15.d$DMAR_Unmarried10 <- 0
  }
}

DMAR.tbl4 <- data.frame(tau.j=tau.j, tau.k=tau.k, log.partial.lik=DMAR.loglik4)

# cutpoint that produces model with the maximum log likelihood
DMAR.tbl4[DMAR.tbl4$log.partial.lik == max(DMAR.tbl4$log.partial.lik), ]
DMAR.cutpt4 <- DMAR.tbl4$tau.k[DMAR.tbl4$log.partial.lik == max(DMAR.tbl4$log.partial.lik)]
DMAR.cutpt5 <- DMAR.tbl4$tau.j[DMAR.tbl4$log.partial.lik == max(DMAR.tbl4$log.partial.lik)]

# assign tau with max log likelihood as cutpoint for DMAR_unmarried
DMAR_Unmarried7 <- ifelse(co15.d$AGED <= DMAR.cutpt5 & co15.d$AGED > 20, 
                          DMAR_Unmarried7 <- co15.d$log.DMAR_r[co15.d$AGED <= DMAR.cutpt5 & co15.d$AGED > 20],
                          DMAR_Unmarried7 <- 0)

DMAR_Unmarried8 <- ifelse(co15.d$AGED > DMAR.cutpt5 & co15.d$AGED < 362, 
                          DMAR_Unmarried8 <- co15.d$log.DMAR_r[co15.d$AGED > DMAR.cutpt5 & co15.d$AGED < 362],
                          DMAR_Unmarried8 <- 0)

DMAR_Unmarried9 <- ifelse(co15.d$AGED <= DMAR.cutpt4 & co15.d$AGED > 1, 
                          DMAR_Unmarried9 <- co15.d$log.DMAR_r[co15.d$AGED <= DMAR.cutpt4 & co15.d$AGED > 1],
                          DMAR_Unmarried9 <- 0)

DMAR_Unmarried10 <- ifelse(co15.d$AGED > DMAR.cutpt4 & co15.d$AGED < 20, 
                           DMAR_Unmarried10 <- co15.d$log.DMAR_r[co15.d$AGED > DMAR.cutpt4 & co15.d$AGED < 20],
                           DMAR_Unmarried10 <- 0)

co15.d$DMAR_Unmarried7 <- DMAR_Unmarried7
co15.d$DMAR_Unmarried8 <- DMAR_Unmarried8
co15.d$DMAR_Unmarried9 <- DMAR_Unmarried9
co15.d$DMAR_Unmarried10 <- DMAR_Unmarried10



####################################################################
# Fit cox proportional hazards model with time-dependent covariates: 
# 5 Cutpoints
####################################################################
cph8 <- coxph(Surv(AGED, DIED) ~ 
                APGAR5_r + log.APGAR5_r +
                BFACIL_Home_intended +
                BFACIL_Other +
                DMAR_Unmarried2 + DMAR_Unmarried4 + DMAR_Unmarried7 + DMAR_Unmarried8 +
                DMAR_Unmarried9 + DMAR_Unmarried10 +
                PREVIS_less_than_10 + log.PREVIS_r1 + 
                PREVIS_10_15 + log.PREVIS_r2 +
                PREVIS_more_than_15 + log.PREVIS_r3 +
                ANY.CIG_Smoker + 
                ANY.CIG_Smoker_quit +
                SEX_male + log.SEX +
                BWTR4_1500_2499grams + 
                BWTR4_227_1499grams +  
                ANOMALY +
                BFED_r + log.BFED + 
                COMBGEST_over_41_weeks + log.COMBGEST9 + 
                COMBGEST_41_weeks + log.COMBGEST8 + 
                COMBGEST_40_weeks + log.COMBGEST7 +
                COMBGEST_37_38_weeks + log.COMBGEST6 + 
                COMBGEST_35_36_weeks + log.COMBGEST5 +
                COMBGEST_25_29_weeks + log.COMBGEST3 + 
                COMBGEST_30_34_weeks + log.COMBGEST4 + 
                COMBGEST_under_20_weeks + log.COMBGEST1 +
                COMBGEST_20_24_weeks + log.COMBGEST2 + 
                uRF_Phype_r + log.uRF_Phype + 
                BMI_Overweight +
                BMI_Obesity1 +
                BMI_Obesity2 +
                BMI_Underweight +
                BMI_Obesity3,
              data=co15.d,
              ties='efron',
              x = TRUE, y = TRUE,
              iter.max = 500)

summary(cph8)
cph8$coefficients

# Test proportional hazards assumption
assess.cph8log <- cox.zph(cph8, transform="log", terms=TRUE, global=TRUE)
assess.cph8log$table

m2a <- coxph(Surv(AGED, DIED) ~ 
               DMAR_Unmarried2 + DMAR_Unmarried4 + DMAR_Unmarried7 + DMAR_Unmarried8 +
               DMAR_Unmarried9 + DMAR_Unmarried10 +
               I(DMAR_Unmarried2*log(AGED)) + I(DMAR_Unmarried4*log(AGED)) +
               I(DMAR_Unmarried7*log(AGED)) + I(DMAR_Unmarried8*log(AGED)) +
               I(DMAR_Unmarried9*log(AGED)) + I(DMAR_Unmarried10*log(AGED)),
             data = co15.d, ties = 'efron')
summary(m2a)

cph8.t <- coxph(Surv(AGED, DIED) ~ 
                APGAR5_r + log.APGAR5_r +
                BFACIL_Home_intended +
                BFACIL_Other +
                DMAR_Unmarried2 + DMAR_Unmarried4 + DMAR_Unmarried7 + DMAR_Unmarried8 +
                DMAR_Unmarried9 + DMAR_Unmarried10 +
                I(DMAR_Unmarried2*log(AGED)) + I(DMAR_Unmarried4*log(AGED)) +
                I(DMAR_Unmarried7*log(AGED)) + I(DMAR_Unmarried8*log(AGED)) +
                I(DMAR_Unmarried9*log(AGED)) + I(DMAR_Unmarried10*log(AGED)) +
                PREVIS_less_than_10 + log.PREVIS_r1 + 
                PREVIS_10_15 + log.PREVIS_r2 +
                PREVIS_more_than_15 + log.PREVIS_r3 +
                ANY.CIG_Smoker + 
                ANY.CIG_Smoker_quit +
                SEX_male + log.SEX +
                BWTR4_1500_2499grams + 
                BWTR4_227_1499grams +  
                ANOMALY +
                BFED_r + log.BFED + 
                COMBGEST_over_41_weeks + log.COMBGEST9 + 
                COMBGEST_41_weeks + log.COMBGEST8 + 
                COMBGEST_40_weeks + log.COMBGEST7 +
                COMBGEST_37_38_weeks + log.COMBGEST6 + 
                COMBGEST_35_36_weeks + log.COMBGEST5 +
                COMBGEST_25_29_weeks + log.COMBGEST3 + 
                COMBGEST_30_34_weeks + log.COMBGEST4 + 
                COMBGEST_under_20_weeks + log.COMBGEST1 +
                COMBGEST_20_24_weeks + log.COMBGEST2 + 
                uRF_Phype_r + log.uRF_Phype + 
                BMI_Overweight +
                BMI_Obesity1 +
                BMI_Obesity2 +
                BMI_Underweight +
                BMI_Obesity3,
              data=co15.d,
              ties='efron',
              x = TRUE, y = TRUE,
              iter.max = 500)

summary(cph8.t)



# only time vary effects now for unmarried7 & 8
cph8 <- coxph(Surv(AGED, DIED) ~ 
                  APGAR5_r + log.APGAR5_r +
                  BFACIL_Home_intended +
                  BFACIL_Other +
                  DMAR_Unmarried2 + DMAR_Unmarried4 + DMAR_Unmarried7 + DMAR_Unmarried8 +
                  DMAR_Unmarried9 + DMAR_Unmarried10 +
                  I(DMAR_Unmarried7*log(AGED)) + I(DMAR_Unmarried8*log(AGED)) +
                  PREVIS_less_than_10 + log.PREVIS_r1 + 
                  PREVIS_10_15 + log.PREVIS_r2 +
                  PREVIS_more_than_15 + log.PREVIS_r3 +
                  ANY.CIG_Smoker + 
                  ANY.CIG_Smoker_quit +
                  SEX_male + log.SEX +
                  BWTR4_1500_2499grams + 
                  BWTR4_227_1499grams +  
                  ANOMALY +
                  BFED_r + log.BFED + 
                  COMBGEST_over_41_weeks + log.COMBGEST9 + 
                  COMBGEST_41_weeks + log.COMBGEST8 + 
                  COMBGEST_40_weeks + log.COMBGEST7 +
                  COMBGEST_37_38_weeks + log.COMBGEST6 + 
                  COMBGEST_35_36_weeks + log.COMBGEST5 +
                  COMBGEST_25_29_weeks + log.COMBGEST3 + 
                  COMBGEST_30_34_weeks + log.COMBGEST4 + 
                  COMBGEST_under_20_weeks + log.COMBGEST1 +
                  COMBGEST_20_24_weeks + log.COMBGEST2 + 
                  uRF_Phype_r + log.uRF_Phype + 
                  BMI_Overweight +
                  BMI_Obesity1 +
                  BMI_Obesity2 +
                  BMI_Underweight +
                  BMI_Obesity3,
                data=co15.d,
                ties='efron',
                x = TRUE, y = TRUE,
                iter.max = 500)

summary(cph8)



####################################################################
# Compare models cph3, cph4, cph7 and cph8
####################################################################
# AIC
extractAIC(cph8) ; extractAIC(cph7) ; extractAIC(cph4) ; extractAIC(cph3)

# Log likelihood
logLik(cph8) ; logLik(cph7) ; logLik(cph4) ; logLik(cph3)

# Analysis of Deviance
anova(cph8, cph7, cph4, cph3, test="Chisq")

# Concordance
concordance(cph8)
concordance(cph7)
concordance(cph4)
concordance(cph3)

# Conclusion: cph8 is the best model


# Export CO15.d to CSV
write.csv(co15.d, file="Data/co15_d.csv", row.names=FALSE)


####################################################################
# Diagnositcs
####################################################################
# Test proportional hazards assumption
assess.cph5id <- cox.zph(cph5, transform="identity", terms=TRUE, global=TRUE)
assess.cph5km <- cox.zph(cph5, transform="km", terms=TRUE, global=TRUE)
assess.cph5log <- cox.zph(cph5, transform="log", terms=TRUE, global=TRUE)

# scaled Schoenfeld residuals
par(mfrow=c(2,3))
plot(assess.cph5id, col="red")
ggcoxzph(assess.cph5id)

# Dfbeta residuals
ggcoxdiagnostics(cph5, type = "dfbeta", linear.predictions = TRUE, ggtheme = theme_bw())
ggcoxdiagnostics(cph5, type = "dfbetas", linear.predictions = TRUE, ggtheme = theme_bw())

# Deviance residuals
plot(cph5$linear.predictors, residuals(cph5, type="deviance"), pch=20,
     main = "Deviance Residuals", xlab="Deviance", ylab="Linear Predictors")
abline(h = 0)
ggcoxdiagnostics(cph5, type = "deviance", linear.predictions = TRUE, ggtheme = theme_bw())

# Schoenfeld residuals
ggcoxdiagnostics(cph5, type = "schoenfeld", linear.predictions = TRUE, ggtheme = theme_bw())

# Martingale residuals
plot(cph5$linear.predictors, residuals(cph5, type="martingale"), pch=20)
ggcoxdiagnostics(cph5, type = "martingale", linear.predictions = TRUE, ggtheme = theme_bw())

# Score residuals
ggcoxdiagnostics(cph5, type = "score", linear.predictions = TRUE, ggtheme = theme_bw())

# Partial residuals
ggcoxdiagnostics(cph5, type = "partial", linear.predictions = TRUE, ggtheme = theme_bw())

# martingale residuals vs. 
ggcoxfunctional(Surv(AGED, DIED) ~ APGAR5_r + log.APGAR5_r, data=co15.d)

