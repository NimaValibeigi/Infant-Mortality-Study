# CS2_infant_mortality_study
STAT 634, Case Study 2: Infant Mortality Study

Everything here is found under the "SAS Code" folder. Dataset '.csv' file, "Link15.csv" will also be mentioned on BB submission. 

Before anything, please run "NCHS_CO15_import.sas" 
To see loaded data into SAS, visit "Load SAS Database, CO15.sas"
To see general descriptives, visit "Descriptive Statistics.sas"
To see Odds Ratios of the variables, see "Odds Ratios (Unadj.).sas"
To see how the data was recoded, visit "OfficialRecode.sas"  

To see the loaded data for the missing and non-missing data, and further logistic regression analysis and diagnostics, visit "Logistic Regression Models.R" 
To see the T-test analysis on missing versus non-missing datasets, visit "DIEDmissinganalysis.R"
To see the misc analysis on the missing versus non-missing dataset, visit "missingdataanalysis.R" 

To see the AIC/BIC Optimized Stepwise Logistic Regression Procedure, visit "StepwiseLog(04-26-22).sas" under SAS Code folder
To see the AIC-optimized Logistic Regression Model (with descriptives(ods graphics on is optional)), visit "AICoptimal.sas" under SAS Code folder
To see the BIC-optimized Logistic Regression Model (with descriptives(ods graphics on is optional)), visit "SCoptimal.sas" under SAS Code folder 

To see the unadjusted odds ratios for each variable, visit "Odds Ratios (Unadj.).sas"

To see the Group Lasso for variable selection for the Logistic Regression Model, visit "Grouped_LASSO_Logistic.R"
To see the Group Lasso selected Logistic Model, see "Logistic_From_Lasso.sas"

To see the Group Lasso for the Cox Proportional Hazards Model, visit "Grouped_LASSO.R" 
To see the Cox Proportional Hazards Model in R and SAS, visit "Cox Proportional Hazards.R" and "Cox Proportional Hazards.sas", respectively 

To see the data visualization portion of the study, visit "Data_Visualization.R"



